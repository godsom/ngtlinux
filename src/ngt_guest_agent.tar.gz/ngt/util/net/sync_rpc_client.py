#
# Copyright (c) 2013 Nutanix Inc. All rights reserved.
#
# Author: gasmith@nutanix.com
#
# A mixin for synchronous protobuf RPC clients.
#
# This class is a grab-bag of common patterns we've been using (or wanting) in
# our python protobuf clients. Features include:
#
#  - Synchronous RPC invocation.
#  - Translation of RPC errors to application errors and error stringification.
#  - Size-limited pool of reusable connections.
#
# Usage:
#
#   class MyServiceClient(SyncRpcClientMixin):
#
#     __metaclass__ = sync_rpc_client_metaclass(MyService_Stub)
#
#     def __init__(self):
#       SyncRpcClientMixin.__init__(self, MyServiceError)
#
#     def _create_stub(self):
#       rpc_client = HttpProtobufRpcClient(FLAGS.host, FLAGS.port))
#       return MyService_Stub(rpc_client)
#
#     def _filter_rpc_result(self, rpc, err, ret):
#       if err != MyServiceError.kNoError:
#         raise MyServiceException(self.strerror(), code=err)
#       return ret
#

import contextlib
import threading

from util.base import log
from util.misc.protobuf import protobuf_enum_to_str
from util.net.protobuf_rpc import SyncProtobufRpc
from util.net.rpc_pb2 import RpcResponseHeader

__all__ = [
  "RpcClientError",
  "RpcClientTransportError",
  "SyncRpcClientMixin",
  "sync_rpc_client_metaclass",
]

class RpcClientError(Exception):
  pass

class RpcClientTransportError(RpcClientError):
  pass

def sync_rpc_client_metaclass(stub_class):
  """
  Returns a metaclass that reflects RPC methods for the specified stub.

  Args:
    stub_class (type): The protobuf interface stub class.
  Returns:
    A metaclass.
  """
  class SyncRpcClientMeta(type):
    def __new__(mcs, name, bases, dikt):
      dikt.update(dict(
        (method.name, mcs._reflect_method(method))
          for method in stub_class.DESCRIPTOR.methods
      ))
      return type.__new__(mcs, name, bases, dikt)

    @staticmethod
    def _reflect_method(method):
      def wrapper(self, arg, payload=None, **kwargs):
        return self._invoke_rpc(method.name, arg, payload, **kwargs)
      wrapper.__name__ = method.name
      wrapper.__doc__ = """Issues a %s RPC to the server.""" % (method.name,)
      return wrapper

  return SyncRpcClientMeta

class SyncRpcClientMixin(object):
  def __init__(self, error_class, max_conn=5):
    """
    Instantiates state for the SyncRpcClientMixin.

    Args:
      error_class (type): The protobuf RPC error class.
      max_conn (integer): The maximum number of concurrent RPCs.
    """
    self.__tls = threading.local()
    self.__error_class = error_class
    self.__sema = threading.Semaphore(max_conn)
    self.__stub_lock = threading.Lock()
    self.__stub_pool = []
    self.__stub_gen = 0

  def _create_stub(self):
    """
    Creates a new stub with backing transport.

    Implementations are responsible for overriding this method.

    This method is invoked to lazily establish a stub for an RPC, and is
    guaranteed to be serialized with respect to _reconnect_hook().
    """
    raise NotImplementedError()

  def _reconnect_hook(self):
    """
    Resets state during reconnect.

    This method is invoked during a _maybe_reconnect() call, and is guaranteed
    to be serialized with respect to _create_stub().
    """
    pass

  def _maybe_reconnect(self):
    """
    Forces subsequent calls to create new stubs.

    This call must not be invoked from the context of _create_stub().
    """
    with self.__stub_lock:
      if self.__tls.stub_gen != self.__stub_gen:
        return
      self._reconnect_hook()
      del self.__stub_pool[:]
      self.__stub_gen += 1

  def _convert_rpc_error(self, rpc):
    """
    Converts an RPC error to an application error.

    Returns:
      The application error code.
    Raises:
      RpcClientTransportError: A transport error.
      RpcClientError: An RPC error that can't be translated to an app error.
    """
    hdr = rpc.response_header
    try:
      if hdr.rpc_status == hdr.kNoError:
        return self.__error_class.kNoError
      elif hdr.rpc_status == hdr.kAppError:
        return hdr.app_error
      elif hdr.rpc_status == hdr.kCanceled:
        return self.__error_class.kCanceled
      elif hdr.rpc_status == hdr.kTimeout:
        return self.__error_class.kTimeout
      elif hdr.rpc_status == hdr.kTransportError:
        raise RpcClientTransportError(hdr.error_detail)
    except AttributeError:
      pass
    str = protobuf_enum_to_str(RpcResponseHeader, "RpcStatus", hdr.rpc_status)
    raise RpcClientError("%s: %s" % (str, hdr.error_detail))

  def _filter_rpc_result(self, rpc, err, ret):
    """
    Filters the return value for RPC method invocations.

    Implementations are responsible for overriding this method.
    """
    return rpc, err, ret

  @contextlib.contextmanager
  def _stub(self):
    """
    A context manager to obtain a stub for use in making an RPC. This call
    blocks on a semaphore, to limit the number of concurrent RPCs to the
    server, and returns the stub to a pool upon exit.

    Note that the stub obtained via this call may be rather stale. The caller
    is strongly encouraged to retry the first transport error, if one is
    encountered.
    """
    with self.__sema:
      with self.__stub_lock:
        try:
          stub, gen = self.__stub_pool.pop()
          log.CHECK(gen == self.__stub_gen)
        except IndexError:
          stub = self._create_stub()
          gen = self.__stub_gen
        self.__tls.stub_gen = gen
      try:
        yield stub
      finally:
        with self.__stub_lock:
          if gen == self.__stub_gen:
            self.__stub_pool.append((stub, gen))

  def error(self, error=None, error_detail=""):
    """
    Returns/Sets the last encountered error.
    """
    try:
      if error is not None:
        self.__tls.error = error
        self.__tls.error_detail = error_detail
      return self.__tls.error
    except AttributeError:
      return None

  def strerror_no_code(self, error_detail=""):
    """
    Returns an error string for the last encountered error without the error
    code.
    """
    if not error_detail:
      try:
        error_detail = self.__tls.error_detail
      except AttributeError:
        return ""
    return error_detail

  def strerror(self, error_code=None, error_detail=""):
    """
    Returns an error string for the last encountered error.
    """
    if error_code is None:
      try:
        error_code = self.__tls.error
        error_detail = self.__tls.error_detail
      except AttributeError:
        return ""

    error_str = protobuf_enum_to_str(self.__error_class, "Type", error_code)
    if error_detail:
      return "%s: %s" % (error_str, error_detail)
    else:
      return error_str

  def _invoke_rpc(self, method_name, arg, payload=None, **kwargs):
    """
    Invokes an RPC against the remote server and retries transport errors.
    """
    with self._stub() as stub:
      try:
        rpc, err, ret = self.__invoke_rpc(stub, method_name, arg, payload)
      except RpcClientTransportError:
        # The stub may be reused and stale, so allow one transport error.
        log.DEBUG("Retrying %s after transport error" % (method_name,))
        rpc, err, ret = self.__invoke_rpc(stub, method_name, arg, payload)

    self.error(err, rpc.ErrorText())
    if err != self.__error_class.kNoError:
      log.DEBUG("%s: %s" % (method_name, self.strerror()))

    return self._filter_rpc_result(rpc, err, ret)

  def __invoke_rpc(self, stub, method_name, arg, payload):
    """
    Invokes an RPC against the remote server.
    """
    method = getattr(stub, method_name)
    rpc = SyncProtobufRpc()
    rpc.request_payload = payload
    method(rpc, arg, rpc.done_cb)
    ret = rpc.result()
    err = self._convert_rpc_error(rpc)
    return rpc, err, ret
