#
# Copyright (c) 2015 Nutanix Inc. All rights reserved.
#
# Author: ankush.jindal@nutanix.com
#
# This module provides the adapters for sending/serving RPCs over HTTPS
#

import socket
import ssl
import traceback

import util.base.log as log

from cStringIO import StringIO
from httplib import HTTPSConnection
from util.net.rpc import RpcServer, RpcClient

__all__ = [
    "HttpsRpcConnection",
    "HttpsRpcTransport",
]

class HttpsRpcConnection(HTTPSConnection):
  """
  Wrapper for HTTPSConnection to disable Nagle's algorithm.
  """
  def __init__(self, host, port, key_file, cert_file, ca_file, timeout=None):
    # Python 2.7.9+ requires SSL context to communicate with CVM.
    # Check if SSL context is supported and initiate appropriate connection.
    if hasattr(ssl, 'SSLContext'):
      HTTPSConnection.__init__(self, host, port, key_file=key_file,
                               cert_file=cert_file, timeout=timeout,
                               context=ssl.SSLContext(ssl.PROTOCOL_SSLv23))
    else:
      HTTPSConnection.__init__(self, host, port, key_file=key_file,
                               cert_file=cert_file, timeout=timeout)

    # TODO explore the context setting and the protocol options and explore
    # why the default option of setting the context doesn't work.
    self.ca_file = ca_file
    self.key_file = key_file
    self.cert_file = cert_file
    self.timeout = timeout

  def connect(self):
    """
    This function force the underlying SSL library to check server's
    certificates.
    """
    HTTPSConnection.connect(self)
    self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

class HttpsRpcTransport(object):
  """
  Rpc transport that sends RPCs via HTTPS POST.
  """
  def __init__(self, https_connection, base_url):
    """
    Wraps an https_connection object to create an HttpsRpcTransport

    Args:
      https_connection - httplib.HTTPSConnection object for communicating with
                         HTTPS server
      base_url - Base URL of the HTTPS RPC handler
    """
    self.__https_connection = https_connection
    self.__base_url = base_url
    self.__error = ""

  def send(self, rpc_payload, dest="", timeout_ms=None):
    """
    Send an RPC request.

    Args:
      rpc_payload - RPC payload bytes
      dest - destination URL, appended to base_url.
      timeout_ms - RPC timeout in milliseconds. If None, the http connection
                   timeout will be used.
    """
    self.__error = ""
    rpc_url = self.__base_url + dest
    try:
      self.__https_connection.request("POST", rpc_url, rpc_payload)
      return True
    except Exception as ex:
      self.__error = ("httplib send exception: url:%s payload:%s\n%s" %
                      (rpc_url, rpc_payload, traceback.format_exc()))
      self.__https_connection.close()
      return False

  def receive(self):
    try:
      self.__error = ""
      resp = self.__https_connection.getresponse()
      if resp.status != 200:
        self.__error = "HTTP error: %d %s" % (resp.status, resp.read())
        return None

      return resp.read()
    except socket.timeout:
      self.__error = "timed out"
      self.__https_connection.close()
      return None
    except Exception as ex:
      self.__error = "httplib receive exception: %s" % traceback.format_exc()
      self.__https_connection.close()
      return None

  def error(self):
    return self.__error
