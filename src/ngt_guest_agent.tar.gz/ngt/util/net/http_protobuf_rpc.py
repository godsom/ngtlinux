#
# Copyright (c) 2012 Nutanix Inc. All rights reserved.
#
# Author: cui@nutanix.com
#
# This module provides the an implementation of protobuf RPCs over HTTP.
#
# For example usage, see protobuf_rpc.py.
#

import socket

from cStringIO import StringIO

from util.net.http_rpc import HttpRpcTransport, HttpRpcConnection
from util.net.protobuf_rpc import ProtobufRpcClient, ProtobufRpcServer

class HttpProtobufRpcClient(ProtobufRpcClient):
  """
  Client for making Protobuf RPCS via HTTP POST.
  """
  def __init__(self, host, port, url="/rpc",
               timeout_secs=socket._GLOBAL_DEFAULT_TIMEOUT):
    """
    Creates an HttpProtobufRpcClient.

    Args:
      host - host of the HTTP server serving Json RPC requests.
      port - port of the HTTP server serving Json RPC requests.
      url - URL of the HTTP server's POST handler serving Json RPC requests.
      timeout_secs - timeout in seconds for each RPC request.
    """
    ProtobufRpcClient.__init__(self)
    http_connection = HttpRpcConnection(host, port, timeout=timeout_secs)
    self.__transport = HttpRpcTransport(http_connection, url)

  def send_rpc_request(self, service_name, rpc_payload, response_cb,
                       timeout_ms=None):
    """
    Implement the HTTP transport layer of Protobuf RPCs. Called by the
    protobuf RPC layer.
    """
    service_name = service_name.strip("/")
    if not self.__transport.send(rpc_payload, "/%s/" % service_name,
                                 timeout_ms):
      response_cb(None, self.__transport.error())
    else:
      resp = self.__transport.receive()
      response_cb(StringIO(resp or ""), self.__transport.error())

class HttpProtobufRpcServer(ProtobufRpcServer):
  """
  RPC server that serves Protobuf RPCs via HTTP POST requests.
  """
  def __init__(self, http_server, url="/rpc/*"):
    ProtobufRpcServer.__init__(self)
    self.__rpc_svc_map = {}

    http_server.register_POST_handler(url, self.__handle_POST)

  def export_service(self, rpc_svc):
    """
    Register an RPC service to be handled by this RPC server.
    """
    self.__rpc_svc_map[rpc_svc.GetDescriptor().full_name] = rpc_svc
    return True

  def unexport_service(self, rpc_svc):
    """
    Unregister an RPC service from being handled by this RPC server.
    """
    try:
      del self.__rpc_svc_map[rpc_svc.GetDescriptor().full_name]
      return True
    except KeyError:
      return False

  def __handle_POST(self, path, req_headers, request, resp_headers, response):
    """
    Handles HTTP POST request for RPCs

    Args and Return:
      See util.net.http_server.HTTPServer.register_POST_handler()
    """
    rpc_svc = self.__rpc_svc_map.get(path.strip("/"))
    if rpc_svc is None:
      return 404
    self.handle_rpc_request(rpc_svc, StringIO(request), response)
    resp_headers["Content-Type"] = "application/x-rpc"
    if "Reorder-Request" in req_headers:
      resp_headers["Reorder-Request"] = req_headers["Reorder-Request"]
    return 200
