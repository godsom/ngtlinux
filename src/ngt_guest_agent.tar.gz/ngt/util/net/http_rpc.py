#
# Copyright (c) 2012 Nutanix Inc. All rights reserved.
#
# Author: cui@nutanix.com
#
# This module provides the adapters for sending/serving RPCs over HTTP
#

import socket
import traceback

import util.base.log as log

from cStringIO import StringIO
from httplib import HTTPConnection
from util.net.rpc import RpcServer, RpcClient

__all__ = [
    "HttpJsonRpcClient",
    "HttpJsonRpcServer",
    "HttpRpcConnection",
    "HttpRpcTransport",
]

class HttpRpcConnection(HTTPConnection):
  """
  Wrapper for HTTPConnection to disable Nagle's algorithm and enable keepalive.
  """
  def connect(self):
    HTTPConnection.connect(self)
    self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)

class HttpRpcTransport(object):
  """
  Rpc transport that sends RPCs via HTTP POST.
  """
  def __init__(self, http_connection, base_url):
    """
    Wraps an http_connection object to create an HttpRpcTransport

    Args:
      http_connection - httplib.HTTPConnection object for communicating with
                        HTTP server
      base_url - Base URL of the HTTP RPC handler
    """
    self.__http_connection = http_connection
    self.__base_url = base_url
    self.__error = ""

  def send(self, rpc_payload, dest="", timeout_ms=None):
    """
    Send an RPC request.

    Args:
      rpc_payload - RPC payload bytes
      dest - destination URL, appended to base_url.
      timeout_ms - RPC timeout in milliseconds. If None, the http connection
                   timeout will be used.
    """
    self.__error = ""
    rpc_url = self.__base_url + dest
    try:
      self.__http_connection.request("POST", rpc_url, rpc_payload)
      return True
    except Exception as ex:
      self.__error = ("httplib send exception: url:%s payload:%s\n%s" %
                      (rpc_url, rpc_payload, traceback.format_exc()))
      self.__http_connection.close()
      return False

  def receive(self):
    try:
      self.__error = ""
      resp = self.__http_connection.getresponse()
      if resp.status != 200:
        self.__error = "HTTP error: %d %s" % (resp.status, resp.read())
        return None

      return resp.read()
    except socket.timeout:
      self.__error = "timed out"
      self.__http_connection.close()
      return None
    except Exception as ex:
      self.__error = "httplib receive exception: %s" % traceback.format_exc()
      self.__http_connection.close()
      return None

  def error(self):
    return self.__error

class HttpJsonRpcClient(RpcClient):
  """
  Client for making Json RPCs via HTTP POST.
  """
  def __init__(self, host, port, url, timeout=socket._GLOBAL_DEFAULT_TIMEOUT):
    """
    Creates an HttpJsonRpcClient.

    Args:
      host - host of the HTTP server serving Json RPC requests.
      port - port of the HTTP server serving Json RPC requests.
      url - URL of the HTTP server's POST handler serving Json RPC requests.
      timeout - timeout in seconds for each RPC request.
    """
    http_connection = HttpRpcConnection(host, port, timeout=timeout)
    http_transport = HttpRpcTransport(http_connection, url)
    RpcClient.__init__(self, http_transport)

# JavaScrpit helper code for making JSON RPC request.
_MAKERPC_JS = """
// Provide XMLHttpRequest for IE
if (typeof XMLHttpRequest == "undefined")
  XMLHttpRequest = function () {
    try { return new ActiveXObject("Msxml2.XMLHTTP.6.0"); } catch (e) {}
    try { return new ActiveXObject("Msxml2.XMLHTTP.3.0"); } catch (e) {}
    try { return new ActiveXObject("Microsoft.XMLHTTP"); }  catch (e) {}
    throw new Error("This browser does not support XMLHttpRequest.");
  };

function stringify_request(oid, method, kwargs)
{
  var request = {'.oid': oid, '.method': method, '.kwargs': kwargs};
  return JSON.stringify(request);
}

function parse_response(xmlhttp)
{
  if (xmlhttp.status != 200)
    throw 'HTTPError ' + xmlhttp.status + ': ' + xmlhttp.responseText;
  var response = JSON.parse(xmlhttp.responseText);
  if ('.error' in response)
    throw 'RPCError: ' + response['.error'];
  if ('.exception' in response)
    throw 'RPCException: ' + response['.exception'];
  return response['.return'];
}

function make_rpc_sync(method, kwargs) {
  var xmlhttp = new XMLHttpRequest();
  var reqdata = stringify_request(this._oid, method, kwargs);
  xmlhttp.open('POST', this._url, false);
  xmlhttp.send(reqdata);
  return parse_response(xmlhttp);
}

function make_rpc_async(method, kwargs) {
  var xmlhttp = new XMLHttpRequest();
  var reqdata = stringify_request(this._oid, method, kwargs);
  var url = this._url;
  return function(done, error) {
    xmlhttp.onreadystatechange = function () {
      if (this.readyState == 4) {
        var result;
        try {
          result = parse_response(this);
        } catch (e) {
          if (error) error(e);
          return;
        }
        done(result);
      }
    };
    xmlhttp.open('POST', url, true);
    xmlhttp.send(reqdata);
  };
}
"""

class HttpJsonRpcServer(RpcServer):
  """
  Rpc server that serves Json RPCs via HTTP POST requests, and can optionally
  also export Javscript stubs for calling these RPCs from a browser.
  """
  def __init__(self, http_server, url, js_stubs_url=None):
    """
    Create HttpJsonRpcServer, and register with the given http_server.

    http_server - a util.net.http_server.HTTPServer instance
    url - URL of the RPC handler via HTTP POST
    js_stubs_url - if specified, Javscript stubs for exported RPC services are
                   exported through this URL via HTTP GET
    """
    RpcServer.__init__(self)
    http_server.register_POST_handler(url, self.__handle_POST)

    self.__url = url

    if js_stubs_url:
      http_server.register_GET_handler(js_stubs_url,
                                       self.__handle_GET_js_stubs)
      self.__js_rpc_stubs = ""
    else:
      self.__js_rpc_stubs = None

  def export_service(self, target, oid=None):
    """
    Export object for RPC, also export stubs via Javascript.

    Args and Return: same as RpcServer.export_service
    """
    exported = RpcServer.export_service(self, target, oid)
    if exported and self.__js_rpc_stubs is not None:
      self.__generate_js_service_stubs()
    return exported

  def unexport_service(self, target, oid=None):
    """
    Unexport object for RPC, also unexport Javascript stubs.

    Args and Return: same as RpcServer.unexport_service
    """
    unexported = RpcServer.unexport_service(self, target, oid)
    if unexported and self.__js_rpc_stubs is not None:
      self.__generate_js_service_stubs()
    return unexported

  def __handle_POST(self, path, req_headers, request, resp_headers, response):
    """
    Handles HTTP POST request for RPCs

    Args and Return:
      See util.net.http_server.HTTPServer.register_POST_handler()
    """
    self.handle_jsonrpc(StringIO(request), response)
    return 200

  def __handle_GET_js_stubs(self, path, req_headers, resp_headers, response):
    """
    Handles HTTP GET request for Javascript RPC stubs.

    Args and Return:
      See util.net.http_server.HTTPServer.register_GET_handler()
    """
    resp_headers["Content-type"] = "text/javascript"
    response.write(_MAKERPC_JS)
    response.write(self.__js_rpc_stubs)
    return 200

  @staticmethod
  def __generate_js_method_stub(name, argspec):
    """
    Generate Javascript stub method with the specified name and argspec.

    Returns:
      JavaScript code as a list of lines.
    """
    num_required_args = len(argspec.args)
    if argspec.defaults:
      num_required_args -= len(argspec.defaults)

    lines = []
    lines.append("function (%s) {" % ", ".join(argspec.args))

    # For each required arg, generate code to check that it's not undefined.
    for arg in argspec.args[:num_required_args]:
      lines.append("  if (%s === undefined) throw '%s undefined';" %
                   (arg, arg))

    # Make a Json out of args, and call _make_rpc() helper method.
    args = "{%s}" % ", ".join("'%s':%s" % (arg, arg) for arg in argspec.args)
    lines.append("  return this._make_rpc('%s', %s);" % (name, args))
    lines.append("}")

    return lines

  def __generate_js_service_stubs(self):
    """
    Generate Javscript stubs for all exported objects.

    Args:
      oid - oid of the exported object.
      handler_map - map from method to name handler and argspec.

    Returns:
      JavaScript code as string.
    """
    jsfile = StringIO()

    for oid, handler_map in self._oid_map.iteritems():
      jsfile.write("var %s = {\n" % oid);

      # Write out properties.
      jsfile.write("  _oid: '%s',\n" % oid)
      jsfile.write("  _url: '%s',\n" % self.__url)

      # Write out stubs for each method in target object.
      for name, (method, argspec) in handler_map.iteritems():
        js_stub_lines = self.__generate_js_method_stub(name, argspec)
        jsfile.write("  '%s': %s,\n" % (name, "\n  ".join(js_stub_lines)))

      jsfile.write("  _make_rpc: make_rpc_sync\n")
      jsfile.write("};\n")

    self.__js_rpc_stubs = jsfile.getvalue()
