#
# Copyright (c) 2012 Nutanix Inc. All rights reserved.
#
# Author: bvk@nutanix.com, cui@nutanix.com
#
# This module implements Rpc server and client functionality.  Any python
# object can export its methods -- that follow the below restrictions -- to
# remote clients through the RpcServer objects. RpcClient objects can be used
# to access the exported object's methods.
#
# Restrictions on Rpc methods:
#
# Rpc methods should not raise any exceptions, must only use values that can be
# encoded in json as its arguments and return values. These values include:
# None, bools, ints, longs, strings and lists, dicts with the combinations of
# former values. Also, dicts must use only strings as the keys.
#
# Custom class objects are not allowed as arguments or as return values.
#
# Tuple's are treated as lists, so same rules as the lists apply.
#
# As a general rule, value 'v' is okay as long as, json.dumps({'v': v})
# succeeds.
#
# Example usage:
#
#   # Create any object whose methods should be callable remotely.
#   service = ZookeeperService(...)
#
#   # Create an Rpc server that exports Rpc services.
#   server = RpcServer()
#   server.export_service(service)
#   ...
#   server.handle_jsonrpc(req_fileobj, resp_fileobj)
#   ...
#
# On the client side:
#
#   # Create an Rpc client object for a remote service.
#   http_transport = ...
#   rpc_client = RpcClient(http_transport)
#
#   zkservice = rpc_client.import_service(ZookeeperService)
#
# NOTES on JSON Rpcs:
#
# 1. Json Rpcs rely on special keys given below for handling the Rpcs.
#
#    .oid - This key contains the unique id representing Rpc target object.
#
#    .method - This key contains the Rpc method name.
#
#    .kwargs - This key contains the all arguments as a mapping for name to
#              value. The RPC framework will inspect methods the interface
#              class during rpc_service.import_service(), and assign
#              names to arguments when stub methods are called.
#
#    .return - This key contains the Rpc method return value.
#
#    .error - This key is used to report Rpc framework errors, like bad Rpc.
#
#    .exception - This key returns the exception message raised by the Rpc.
#

import inspect
import json
import traceback

import util.base.log as log

class RpcError(object):
  """
  RpcError objects are used to distinguish the Rpc framework errors from the
  return value of Rpc target invocation. Example usage is:

  ret = proxy.remote_method(parameters)
  if isinstance(ret, RpcError):
    raise RuntimeError("Rpc failed")
  ...

  """
  def __init__(self, error, exception=None):
    self.error = error
    self.exception = exception

  def __nonzero__(self):
    return False

  def __str__(self):
    return "RPCError: %s" % self.error

class JsonRequest(object):

  @staticmethod
  def decode(request):
    """
    Parses a Json Rpc request.

    request: Json encoded Rpc request dict.

    Returns (oid, method, kwargs) tuple if Rpc request is parsed
    successfully; Returns None otherwise.
    """
    try:
      request = json.loads(request)
    except Exception as ex:
      return None

    oid = request.get(".oid", None)
    method = request.get(".method", None)
    kwargs = request.get(".kwargs", {})
    if not oid or not method:
      return None
    return oid, method, kwargs

  @staticmethod
  def create(oid, method, kwargs):
    """
    Returns a json Rpc request to invoke a remote method.

    oid: Unique name to identify the Rpc object exporting the Rpc service.

    method: A method name of the object exporting the Rpc service.

    kwargs: Named arguments to the method for *kwargs expansion.

    Returns a json encoded dict with Rpcs parameters. Returns None if arguments
    are malformed.
    """
    try:
      request = {".oid":oid, ".method":method, ".kwargs":kwargs}
      return json.dumps(request)
    except:
      log.ERROR("Cannot convert arguments to Json Rpc request format")
      return None

class JsonResponse(object):

  @staticmethod
  def decode(response):
    """
    Parse the Json reponse from the RpcServer.

    response: Json encoded Rpc response received from the RpcServer.

    Returns an instance of RpcError if Rpc execution failed; Otherwise returns
    the Rpc target method's return value.
    """
    try:
      response = json.loads(response)
    except:
      response = {}

    try:
      error = response.get(".error", None)
      exception = response.get(".exception", None)
      if error:
        return RpcError(error, exception)

      if not response.has_key(".return"):
        errmsg = "Json Rpc response seems corrupted; .return is expected"
        log.ERROR(errmsg)
        return RpcError(errmsg)

      return response[".return"]
    except:
      log.FATAL(traceback.format_exc())

  @staticmethod
  def create(result):
    """
    Returns a json encoded Rpc response with the error and return values.

    result: Json encoded response of the Rpc method invocation, or None
            if result could not be serialized. If result is an instance
            of RpcError then Rpc is considered as failed.
    """
    if isinstance(result, RpcError):
      response = {".error": result.error, ".exception": result.exception}
    else:
      response = {".return": result}
    try:
      return json.dumps(response)
    except:
      log.ERROR("Cannot convert result to Json Rpc response format: %s" %
                response)
      return None

class RpcInspect(object):
  """
  Utility class that provides routines for inspecting imported/exported
  objects for RPC methods.
  """
  @staticmethod
  def decorate_rpc_handler(method):
    """
    Decorator to make a function/method into RPC handler method.
    """
    # Attach a private attribute __is_rpc to identify this method
    # as an rpc handler.
    method.__is_rpc_handler = True
    return method

  @staticmethod
  def get_rpc_handlers(target):
    """
    Inspect the target RPC object or class, extract the RPC methods it.

    target: the object whose methods are to be exported, or the class
            whose methods are to be imported.

    Returns dict of RPC handlers mapping from method name to tuple
            (method callable, method argspec)
    """
    result = {}

    members = inspect.getmembers(target, predicate=inspect.ismethod)
    for name, method in members:
      try:
        if method.__is_rpc_handler:
          argspec = inspect.getargspec(method)
          del argspec.args[0] # First argument is self, remove
          result[name] = (method, argspec)
      except AttributeError:
        pass

    return result

class RpcServer(object):
  def __init__(self):
    self._oid_map = {}

  def export_service(self, target, oid=None):
    """
    Exports methods of an objects to remote clients over Rpc.

    target: The object whose methods are to be exported.

    oid: Unique id for the object to distingush between multiple objects of
         same type. When None, it defaults to class name of the target.

    Returns True if successful and False otherwise.
    """
    try:
      if oid is None:
        oid = target.__class__.__name__

      if oid in self._oid_map:
        log.WARNING("Overwriting an existing Rpc target object, %s" % oid)

      self._oid_map[oid] = RpcInspect.get_rpc_handlers(target)
      return True
    except:
      log.FATAL(traceback.format_exc())

  def unexport_service(self, target, oid=None):
    """
    Unregister an object from Rpcs.

    target: The object whose methods are to be exported.

    oid: Unique id for the object to distingush between multiple objects of
         same type. When None, it defaults to class name of the target.

    Returns True if successful and False otherwise.
    """
    try:
      if oid is None:
        oid = target.__class__.__name__

      if oid not in self._oid_map:
        log.ERROR("Attempt to unregister an Rpc object %s that doesn't exist"
                  % oid)
        return False

      del self._oid_map[oid]
      return True
    except:
      log.FATAL(traceback.format_exc())

  def handle_jsonrpc(self, request, response):
    """
    Handles one jsonrpc request.

    request: A file-like object where the JSON encoded rpc request is
             read from.

    response: A file-like object where JSON encoded response should be
              written to.

    Returns True if a request was handled successfully and False otherwise.
    """
    request = JsonRequest.decode(request.read())
    if request is None:
      log.ERROR("Failed to decode input jsonrpc request")
      return False

    oid, method, kwargs = request
    handler_map = self._oid_map.get(oid, None)
    if handler_map is None:
      log.DEBUG("%r" % self._oid_map.keys())
      errmsg = "Json Rpc request for unknown Rpc object %s" % oid
      log.ERROR(errmsg)
      response.write(JsonResponse.create(RpcError(errmsg)))
      return False

    handler, argspec = handler_map.get(method, (None, None))
    if handler is None:
      errmsg = ("Json Rpc request for unknown method %s of object %s" %
                (method, oid))
      log.ERROR(errmsg)
      response.write(JsonResponse.create(RpcError(errmsg)))
      return False

    try:
      ret = handler(**kwargs)
      log.DEBUG("Rpc request: %s.%s(%s) -> %s" % (oid, method, kwargs, ret))
    except Exception as ex:
      errmsg = "Caught exception: %s\n%s" % (ex, traceback.format_exc())
      log.ERROR(errmsg)
      response.write(JsonResponse.create(RpcError(errmsg, str(ex))))
      return False

    response_payload = JsonResponse.create(ret)
    if not response_payload:
      errmsg = ("Return value of Json Rpc method %s cannot be converted "
                "to json-dict format") % (method)
      # Already logged by JsonResponse.create
      response.write(JsonResponse.create(RpcError(errmsg)))
      return False

    response.write(response_payload)
    return True

class BaseRpcClientStubs(object):
  """
  Base class of all RPC client stub classes, with class methods for
  dynamically adding stub methods by inspecting RPC interface classes.
  """
  def __init__(self, transport, oid):
    self.__oid = oid
    self.__transport = transport

  @classmethod
  def __attach_stub(cls, name, argspec):
    """
    Attach a stub method with the specified name and argspec to this class.
    """
    setattr(cls, name, lambda self, *args, **kwargs:
            self.__make_rpc(name, argspec, args, kwargs))

  @classmethod
  def _attach_stubs(cls, interface):
    """
    Augment class with stub methods matching methods in interface class.
    """
    log.CHECK(cls is not BaseRpcClientStubs,
              "Attaching stubs can only be performed on subclasses of "
              "BaseRpcStubs.")

    handler_map = RpcInspect.get_rpc_handlers(interface)
    for name, (method, argspec) in handler_map.iteritems():
      # This needs to be done in a separate function so the local variables
      # in the current iteration of the loop are copied into their own closure.
      cls.__attach_stub(name, argspec)

  def __make_rpc(self, method, argspec, args, kwargs):
    """
    Helper function for type checking and making RPC requests.
    """
    if argspec.varargs:
      raise TypeError("%s() varargs not supported" %  method)
    if not argspec.keywords:
      extra_keywords = list(set(kwargs.keys()) - set(argspec.args))
      if extra_keywords:
        raise TypeError("%s() got unexpected keyword arguments %r" %
                        (method, extra_keywords[0]))
    if len(args) > len(argspec.args):
      raise TypeError(
        "%s() takes at most %d non-keyword arguments (%d given)" %
        (method, len(argspec.args), len(args)))

    num_required_args = len(argspec.args)
    if argspec.defaults:
      num_required_args -= len(argspec.defaults)

    # For each unamed arg in the argtuple, look up its name in argspec and add
    # to kwargs dict
    ii = 0
    while ii < len(args):
      name = argspec.args[ii]
      if name in kwargs:
        raise TypeError("%s() got mutiple values for keyword argument %r" %
                        (method, name))
      kwargs[name] = args[ii]
      ii += 1

    # For rest of the required args in argspec, check that they are specified
    # by keyword.
    while ii < num_required_args:
      name = argspec.args[ii]
      if name not in kwargs:
        raise TypeError("%s() takes at least %d non-keyword arguments "
                        "(%d given)" % (method, num_required_args, ii))
      ii += 1

    # TODO: support encoding of timeouts.
    request = JsonRequest.create(self.__oid, method, kwargs)
    if not self.__transport.send(request):
      return RpcError("Client transport error: %s" % self.__transport.error())

    response = self.__transport.receive()
    if response is None:
      return RpcError("Client transport error: %s" % self.__transport.error())

    return JsonResponse.decode(response)

class RpcClient(object):
  def __init__(self, transport):
    """
    Creates an RpcClient object:

    transport - object that provides communication interface to the server,
                should implement the following methods:

                send(request) - takes encoded rpc request payload, and sends
                                it to the Rpc server. Returns True on success,
                                False on failure.
                receive() - receives encoded rpc response payload, and returns
                            it as a string, or None on failure.
                error() - returns a description of the last error as string.
    """
    self.__transport = transport

  def import_service(self, interface, oid=None):
    """
    Creates a proxy object that supports same interface as interface, but
    delievers all acts like a proxy to remote object.

    Returns an proxy object of type interface.
    """
    if oid is None:
      oid = interface.__name__

    # If proxy stub already exists for 'interface' interface, reuse it.
    # We save proxy_classes as an attribute of interface class that's private
    # to the RpcClient class. (Python's syntax rule morphs attributes beginning
    # with "__" by prepending the name of the class that owns the current code
    # block. So in this case, interface.__proxy_class actually becomes
    # getattr(interface, "_RpcClient__proxy_class"))
    try:
      proxy_class = interface.__proxy_class
    except AttributeError:
      proxy_class = type("RpcClientStubs(%s)" % interface.__name__,
                         (BaseRpcClientStubs, ), {})
      proxy_class._attach_stubs(interface)
      interface.__proxy_class = proxy_class

    return proxy_class(self.__transport, oid)

rpchandler = RpcInspect.decorate_rpc_handler

__all__ = [RpcError, RpcServer, RpcClient, rpchandler]
