#
# Copyright (c) 2015 Nutanix Inc. All rights reserved.
#
# Author: ankush.jindal@nutanix.com
#
# This module provides an implementation of protobuf RPCs over HTTPS.
#
# For example usage, see protobuf_rpc.py.
#

import socket

from cStringIO import StringIO

from util.net.https_rpc import HttpsRpcTransport, HttpsRpcConnection
from util.net.protobuf_rpc import ProtobufRpcClient, ProtobufRpcServer

class HttpsProtobufRpcClient(ProtobufRpcClient):
  """
  Client for making Protobuf RPCs via HTTPS POST.
  """
  def __init__(self, host, port, key_file, cert_file, ca_file,
               timeout_secs=socket._GLOBAL_DEFAULT_TIMEOUT, url="/rpc"):
    """
    Creates an HttpsProtobufRpcClient.

    Args:
      host - host of the HTTPS server serving RPC requests.
      port - port of the HTTPS server serving RPC requests.
      url - URL of the HTTPS server's POST handler serving RPC requests.
      key_file - Client key to authenticate.
      cert_file - Client certificate.
      ca_file - CA root certificate.
      timeout_secs - timeout in seconds for each RPC request.
    """
    ProtobufRpcClient.__init__(self)
    https_connection = HttpsRpcConnection(host, port, key_file=key_file,
                                          cert_file=cert_file, ca_file=ca_file,
                                          timeout=timeout_secs)
    self.__transport = HttpsRpcTransport(https_connection, url)

  def send_rpc_request(self, service_name, rpc_payload, response_cb,
                       timeout_ms=None):
    """
    Implement the HTTPS transport layer of Protobuf RPCs. Called by the
    protobuf RPC layer.
    """
    service_name = service_name.strip("/")
    if not self.__transport.send(rpc_payload, "/%s/" % service_name,
                                 timeout_ms):
      response_cb(None, self.__transport.error())
    else:
      resp = self.__transport.receive()
      response_cb(StringIO(resp or ""), self.__transport.error())
