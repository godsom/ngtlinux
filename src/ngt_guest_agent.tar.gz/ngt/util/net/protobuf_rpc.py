#
# Copyright (c) 2012 Nutanix Inc. All rights reserved.
#
# Author: cui@nutanix.com
#
# This module provides the adapters for sending/serving Nutanix protobuf RPCs
# as described in util/net/rpc.h.
#
# See util/net/rpc.h for example of how to define protobuf RPC services in
# .proto files.
#
# Example usage on client side.
#
#   # Create an instance of any implementation of ProtobufRpcClient.
#   rpc_client = HttpProtobufRpcClient(...)
#
#   # Use rpc_client to instantiate service Stub.
#   service1 = Service1_Stub(rpc_client)
#
#   # The same rpc_client can be reused for multiple services.
#   service2 = Service2_Stub(rpc_client)
#
#   # Create a ProtobufRpc object for each rpc call.
#   rpc11 = ProtobufRpc()
#
#   # Create and fill in argument protobuf message for the method.
#   arg11 = Service1Method1Arg()
#   ...
#
#   # Define a done callback for each rpc call, takes a single argument,
#   # which is the return protobuf.
#   def done11(service1_method1_ret):
#     if service1_method1_ret is None:
#       # RPC failed, figure out why. Use the rpc controller object in the
#       # closure.
#       print rpc.response_header
#     else:
#       assert isinstance(service1_method1_ret, Service1Method1Ret)
#       # Do something with the return
#
#   # Make the RPC call through the stub method. Takes 3 arguments:
#   #   rpc controller, argument protobuf, done callback
#   # Done callback is invoked when the RPC finishes. Depending on the
#   # implementation of rpc_client, this call may or may not block.
#   service1.method1(rpc11, arg11, done11)
#
#   # Repeat for other methods.
#   rpc21 = ...
#   arg21 = ...
#   def done21(ret21):
#     ...
#   service2.method2(rpc21, arg21, done21)
#
# Server side handler example:
#
#   # Define a class to implement server side handlers, deriving from the
#   # generated interface class.
#
#   import my_service_pb2
#
#   class MyService1(my_service_pb2.Service1):
#
#     def method1(rpc, service1_method1_arg, done):
#       """
#       Handles Service1.method1 RPC.
#
#       Args:
#         rpc - controller for the current rpc.
#         service1_method1_arg - argument protobuf, of type Service1Method1Arg
#         done - done callback, takes a Service1Method1Ret protobuf, or None
#       """
#       ...
#
# Exporting services to RPC server:
#
#  # Create an instance of any ProtobufRpcServer implementation.
#  rpc_server = HttpProtobufRpcServer(http_server)
#
#  # Create an instance of the service handler.
#  service1 = MyService1(...)
#
#  # Export service.
#  rpc_server.export_service(service1)
#

import os
import struct
import threading
import traceback
import time

from cStringIO import StringIO

from google.protobuf.message import EncodeError, DecodeError
from google.protobuf.service import RpcController, RpcChannel
from util.base import log
from util.net.rpc_pb2 import RpcRequestHeader, RpcResponseHeader, \
  timeout_msecs

class ProtobufRpc(RpcController):
  """
  Implements google.protobuf.service.RpcController.

  Members with CamelCaseNames implements abstract methods defined by the
  Google RPC framework. Members with underscore_names are our own extensions.

  Attributes:
     request_header: RpcRequestHeader protobuf of the current RPC.
     resposne_header: RpcResponseHeader protobuf of the current RPC.
     request_payload: RPC Payload from the client.
     response_payload: RPC Payload from the server.
  """
  def __init__(self):
    self.Reset()

  def Reset(self):
    self.request_header = RpcRequestHeader()
    self.response_header = RpcResponseHeader()
    self.request_payload = None
    self.response_payload = None

  def Failed(self):
    return (self.response_header.rpc_status not in
            (self.response_header.kNoError, self.response_header.kAppError))

  def ErrorText(self):
    return self.response_header.error_detail

  def SetFailed(self, error_detail):
    """
    Called by the RPC framework when there are errors resolving methods.
    """
    self.set_error(RpcResponseHeader.kMethodError, error_detail)

  def set_error(self, error_code, error_detail):
    """
    Called by the RPC framework when there are any errors making/handing RPCs.

    error_code: an RpcResponseHeader.RpcStatus enum value.

    error_detail: string describing the error.
    """
    self.response_header.rpc_status = error_code
    if error_detail is not None:
      self.response_header.error_detail = error_detail
    else:
      self.response_header.ClearField("error_detail")

  def set_app_error(self, error_code, error_detail):
    """
    Called by RPC handler application when there are errors handling the RPC.

    error_code: application specific error code.

    error_detail: application specific error string.
    """
    self.set_error(RpcResponseHeader.kAppError, error_detail)
    if error_code is not None:
      self.response_header.app_error = error_code

class SyncProtobufRpc(ProtobufRpc):
  """
  Helper for making protobuf RPCs and blocking on the result.
  """
  def __init__(self):
    ProtobufRpc.__init__(self)
    self.__result = None
    self.__done_ev = threading.Event()

  def done_cb(self, result):
    self.__result = result
    self.__done_ev.set()

  def result(self):
    self.__done_ev.wait()
    return self.__result

def _serialize_protobuf_rpc(header_proto, body_proto, payload, outfile):
  """
  Serializes a Protobuf RPC request/response to a output file.

  header_proto: protobuf header of request/response.

  body_proto: protobuf of the request/response body.

  payload: binary payload of the request/response.

  outfile: file object to which the serialized request/response will be written.
  """
  try:
    if body_proto is not None:
      serialized_body = body_proto.SerializeToString()
      header_proto.protobuf_size = len(serialized_body)
    else:
      header_proto.ClearField("protobuf_size")
      serialized_body = None

    if payload is not None:
      header_proto.payload_size = len(payload)
    else:
      header_proto.ClearField("payload_size")

    serialized_header = header_proto.SerializeToString()
    outfile.write(struct.pack("!I", len(serialized_header)))
    outfile.write(serialized_header)

    if serialized_body is not None:
      outfile.write(serialized_body)
    if payload is not None:
      outfile.write(payload)
  except EncodeError:
    log.ERROR(traceback.format_exc())
    log.FATAL("Failed to serialized protobuf for RPC")

def _checked_read_file(infile, size):
  """
  Reads 'size' bytes from infile, raises IOError on short count.
  """
  buf = infile.read(size)
  if len(buf) != size:
    raise IOError("Not enough bytes read")
  return buf

class ProtobufRpcClient(RpcChannel):
  """
  RpcChannel responsible for serializing and deserializing RPC on client side,
  should be extended with implementation transport layer.
  """

  def __init__(self):
    """
    Create RPC client to a specific server.

    transport: RPC transport object for communicating with server.
    """
    self.__next_id_lock = threading.Lock()
    self.__next_id = 0
    self.__client_id = struct.unpack("I", os.urandom(4))[0]

  def __next_rpc_id(self):
    with self.__next_id_lock:
      ret = ((self.__client_id & 0x7FFFFFFF) << 32) | self.__next_id
      self.__next_id += 1
      return ret

  def send_rpc_request(self, service_name, rpc_payload, response_cb,
                       timeout_ms=None):
    """
    Sends one RPC request. To be implemented by subclasses.

    service_name: full name of the requested RPC service.

    rpc_payload: serialized payload of the RPC request.

    response_cb: callback to invoke when response comes back, takes arguments:
                 resp_file: file like object containing the RPC response, or
                            None if the RPC request coult not be sent.

    timeout_ms: RPC timeout in milliseconds. If None, the timeout setup on the
                HTTP connection will be used.
    """
    raise NotImplementedError()

  def CallMethod(self, method_desc, rpc, req_proto, response_class, done):
    """
    Call the method identified by the descriptor.

    method_desc: method descriptor.

    rpc: rpc controller.

    req_proto: request protobuf object.

    response_class: class of the response protobuf.

    done: done callback.
    """
    header = rpc.request_header
    header.rpc_id = self.__next_rpc_id()
    header.send_time_usecs = int(time.time() * 1e6)
    header.method_name = method_desc.name
    timeout_ms = None

    rpc_options = method_desc.GetOptions()
    if rpc_options:
      if rpc_options.HasExtension(timeout_msecs):
        timeout_ms = rpc_options.Extensions[timeout_msecs]

    outfile = StringIO()
    _serialize_protobuf_rpc(header, req_proto, rpc.request_payload, outfile)

    def response_cb(resp_file, error_msg=""):
      if resp_file is None:
        # RPC request could not be sent.
        rpc.set_error(RpcResponseHeader.kTransportError,
                      "Failed to send RPC request")
        done(None)
      elif error_msg.strip() == "timed out":
        rpc.set_error(RpcResponseHeader.kTimeout, "RPC request timed out")
        done(None)
      else:
        self.__handle_rpc_response(rpc, resp_file, response_class, done)

    service_name = method_desc.containing_service.full_name
    self.send_rpc_request(service_name, outfile.getvalue(), response_cb,
                          timeout_ms)

  def __handle_rpc_response(self, rpc, resp_file, response_class, done):
    """
    Handle RPC response.

    rpc: controller of current RPC.

    resp_file: file object from which to read the RPC response bytestream.

    response_class: class of the RPC response protobuf.

    done: callback invoked with the response protobuf to report result back
          to the RPC caller.
    """
    read_resp_file = lambda size: _checked_read_file(resp_file, size)

    try:
      header_size = struct.unpack("!I", read_resp_file(4))[0]
    except (struct.error, IOError):
      rpc.set_error(RpcResponseHeader.kTransportError,
                    "Received buffer is too short")
      done(None)
      return

    try:
      header = rpc.response_header
      header.ParseFromString(read_resp_file(header_size))
    except (DecodeError, IOError):
      rpc.set_error(RpcResponseHeader.kTransportError,
                    "Unable to parse response header")
      done(None)
      return

    if header.protobuf_size < 0 or header.payload_size < 0:
      rpc.set_error(RpcResponseHeader.kTransportError,
                    "Size of protobuf/payload is invalid")
      done(None)
      return

    if rpc.Failed():
      done(None)
      return

    proto = response_class()
    if header.protobuf_size > 0:
      try:
        proto.ParseFromString(read_resp_file(header.protobuf_size))
      except (DecodeError, IOError):
        rpc.set_error(RpcResponseHeader.kTransportError,
                      "Unable to parse response protobuf")
        done(None)
        return

    if header.payload_size > 0:
      rpc.response_payload = read_resp_file(header.payload_size)
      if len(rpc.response_payload) != header.payload_size:
        rpc.set_error(header.rpc_id, RpcResponseHeader.kTransportError,
                      "Incorrect length of payload received")

    done(proto)
    return

class ProtobufRpcServer(object):
  """
  Abstract base class of Protobuf RPC server. Should be extended with
  implementation of the transport layer.
  """

  def __init__(self):
    pass

  def __send_rpc_response(self, rpc, resp_proto, resp_file):
    """
    Sends an RPC response.

    rpc: Controller of the current RPC request.

    resp_proto: response of the RPC request.

    resp_file: file object to which the response byte stream should be
               written to.

    Returns: None
    """
    rpc.response_header.rpc_id = rpc.request_header.rpc_id

    if not rpc.Failed():
      _serialize_protobuf_rpc(rpc.response_header, resp_proto,
                              rpc.response_payload, resp_file)
    else:
      _serialize_protobuf_rpc(rpc.response_header, None, None, resp_file)

  def __send_error_response(self, rpc_id, rpc_status, error_detail, resp_file):
    """
    Sends an RPC error response from the RPC framework.
    """
    header = RpcResponseHeader()
    header.rpc_id = rpc_id
    header.rpc_status = rpc_status
    if error_detail is not None:
      header.error_detail = str(error_detail)

    _serialize_protobuf_rpc(header, None, None, resp_file)

  def export_service(self, rpc_svc):
    """
    Register an RPC service to be handled by this RPC server.
    """
    raise NotImplementedError()

  def unexport_service(self, rpc_svc):
    """
    Unregister an RPC service from being handled by this RPC server.
    """
    raise NotImplementedError()

  def handle_rpc_request(self, rpc_svc, req_file, resp_file):
    """
    Handles one RPC request.

    rpc_svc: RPC service that's handling the current request.

    req_file: file object from which to read the request byte stream.

    resp_file: file object to which to write the resposne byte stream.

    Returns: None
    """
    rpc = ProtobufRpc()

    read_req_file = lambda size: _checked_read_file(req_file, size)

    try:
      header_size = struct.unpack("!I", read_req_file(4))[0]
    except (struct.error, IOError):
      self.__send_error_response(-1, RpcResponseHeader.kTransportError,
                                 "Received buffer is too short", resp_file)
      return

    try:
      header = rpc.request_header
      header.ParseFromString(read_req_file(header_size))
    except (DecodeError, IOError):
      self.__send_error_response(-1, RpcResponseHeader.kTransportError,
                                 "Unable to parse request header", resp_file)
      return

    if header.protobuf_size < 0 or header.payload_size < 0:
      self.__send_error_response(
        header.rpc_id, RpcResponseHeader.kTransportError,
        "Size of protobuf/payload is invalid", resp_file)
      return

    method_desc = rpc_svc.GetDescriptor().FindMethodByName(header.method_name)
    if method_desc is None:
      self.__send_error_response(header.rpc_id, RpcResponseHeader.kMethodError,
                                 "Method %s does not exist" %
                                 header.method_name, resp_file)
      return

    proto = rpc_svc.GetRequestClass(method_desc)()
    try:
      proto.ParseFromString(read_req_file(header.protobuf_size))
    except (DecodeError, IOError):
      self.__send_error_response(header.rpc_id,
                                 RpcResponseHeader.kTransportError,
                                 "Unable to parse request protobuf", resp_file)
      return

    if header.payload_size > 0:
      try:
        rpc.request_payload = read_req_file(header.payload_size)
      except IOError:
        self.__send_error_response(header.rpc_id,
                                   RpcResponseHeader.kTransportError,
                                   "Incorrect length of payload received",
                                   resp_file)

    def done_callback(proto):
      self.__send_rpc_response(rpc, proto, resp_file)

    rpc_svc.CallMethod(method_desc, rpc, proto, done_callback)

class ProtobufClientError(Exception):
  pass
