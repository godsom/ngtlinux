#
# Copyright (c) 2013-2016 Nutanix Inc. All rights reserved.
#
# Author: aj@nutanix.com (AJ Kaufmann)
#
# Description: Utility library for common protobuf operations.
#

import base64

from google.protobuf.descriptor import FieldDescriptor

__all__ = [
  "get_method_descriptor",
  "get_request_type",
  "get_response_type",
  "is_repeated_field",
  "json2pb",
  "pb2json",
  "protobuf_enum_to_str",
  "safe_has_field",
]


# Because protobuf.py module is part of util, we cannot just directly
# import any higher level modules. E.g. Minerva component has its own
# python egg. This module is part of the minerva python egg, but
# uhura is not included in the egg. Directly importing
# `from uhura.uhura_interface_pb2 import UhuraRpcSvc` will lead to
# ImportError.
_SERVICE_MODULE_PATHS = {
  "Acropolis": (
      "acropolis.acropolis_interface_pb2",
      "AcropolisRpcSvc"
  ),
  "Ergon": (
      "ergon.ergon_interface_pb2",
      "ErgonRpcSvc"
  ),
  "MinervaCvm": (
      "minerva.interface.minerva_cvm_interface_pb2",
      "MinervaCvmRpcSvc"
  ),
  "Uhura": (
      "uhura.uhura_interface_pb2",
      "UhuraRpcSvc"
  ),
}

_SERVICES = {}
def _import_service_classes():
  for service_name, (module_name, class_name) in _SERVICE_MODULE_PATHS.items():
    try:
      module = __import__(module_name, fromlist=[class_name])
    except ImportError:
      continue
    try:
      service_class = getattr(module, class_name)
    except AttributeError:
      continue
    _SERVICES[service_name] = service_class

_import_service_classes()

def pb2json(msg, b64_bytes=True, convert_enum_to_str=False, conversions=None):
  """
  Converts a protobuf message to a JSON dictionary object.

  By default, bytes fields are base64-encoded in the JSON object. If disabled,
  the resulting JSON cannot be parsed back to a protobuf via json2pb().

  Args:
    b64_bytes (boolean): Whether to base64-encode byte fields.
    convert_enum_to_str (boolean): Whether to convert enum to string labels.
    conversions ([(function, function)]): Caller-provided conversions.
  """
  def recurse_func(desc, val):
    return pb2json(val, b64_bytes, convert_enum_to_str, conversions)

  def b64_bytes_func(desc, val):
    if b64_bytes:
      return base64.b64encode(val)
    else:
      return val

  def convert_enum_to_str_func(desc, val):
    if convert_enum_to_str:
      return unicode(desc.enum_type.values_by_number[int(val)].name)
    else:
      return val

  conversion_functions = (
      [ ( lambda d: d.type == d.TYPE_MESSAGE, recurse_func ),
        ( lambda d: d.type == d.TYPE_BYTES, b64_bytes_func ),
        ( lambda d: d.type == d.TYPE_ENUM, convert_enum_to_str_func ),
      ] + (conversions or []))
  def val_to_json(desc, val):
    for condition, function in conversion_functions:
      if condition(desc):
        val = function(desc, val)

    return val

  obj = {}
  if msg:
    for desc, val in msg.ListFields():
      if desc.label == desc.LABEL_REPEATED:
        obj[desc.name] = [ val_to_json(desc, v) for v in val ]
      else:
        obj[desc.name] = val_to_json(desc, val)
  return obj

def json2pb(obj, msg):
  """
  Converts a JSON dictionary object to a protobuf message.

  Bytes fields are assumed to be base64-encoded in the JSON object.
  """
  for key, obj_val in obj.iteritems():
    desc = msg.DESCRIPTOR.fields_by_name[key]
    msg_val = getattr(msg, key)
    if desc.label == desc.LABEL_REPEATED:
      if desc.type == desc.TYPE_MESSAGE:
        map(lambda item: json2pb(item, msg_val.add()), obj_val)
      elif desc.type == desc.TYPE_BYTES:
        msg_val.extend(map(base64.b64decode, obj_val))
      elif desc.type == desc.TYPE_ENUM and isinstance(obj_val, basestring):
        msg_val.extend(desc.enum_type.values_by_name[obj_val].number)
      else:
        msg_val.extend(obj_val)
    else:
      if desc.type == desc.TYPE_MESSAGE:
        json2pb(obj_val, msg_val)
      elif desc.type == desc.TYPE_BYTES:
        setattr(msg, key, base64.b64decode(obj_val))
      elif desc.type == desc.TYPE_ENUM and isinstance(obj_val, basestring):
        setattr(msg, key, desc.enum_type.values_by_name[obj_val].number)
      else:
        setattr(msg, key, obj_val)
  return msg

def protobuf_enum_to_str(pb, enum, val):
  """
  Returns the stringified name of the protobuf enum value.
  """
  return pb.DESCRIPTOR.EnumValueName(enum, val)

def safe_has_field(proto, field):
  """
  For convenience of testing if an optional field is present.
  """
  try:
    return proto.HasField(field)
  except ValueError:
    return False

def is_repeated_field(proto, name):
  """
  Returns whether a protobuf field is repeated.
  """
  return (proto.DESCRIPTOR.fields_by_name[name].label ==
          FieldDescriptor.LABEL_REPEATED)

def get_method_descriptor(service_name, method_name):
  """
  Returns: (google.protobuf.descriptor.MethodDescriptor)
    Returns method descriptor of method `method_name` in service `service_name`.
    Returns None if method or service is not found.

  See:
    _SERVICES: Dictionary mapping service_name to GeneratedServiceType.
  """
  try:
    return _SERVICES[service_name].GetDescriptor().FindMethodByName(method_name)
  except KeyError:
    return None

def get_request_type(service_name, method_name):
  """
  Returns:
    Protobuf message type corresponding to argument of method
    `method_name` in service `service_name`.
    None if could not resolve service_name or method_name.

  Example:
  >>> get_request_type("Ergon", "TaskCreate")
  <class 'ergon.ergon_interface_pb2.TaskCreateArg'>
  """
  method_desc = get_method_descriptor(service_name, method_name)
  if method_desc:
    return _SERVICES[service_name].GetRequestClass(method_desc)
  else:
    return None

def get_response_type(service_name, method_name):
  """
  Returns:
    Protobuf message type corresponding to response of method
    `method_name` in service `service_name`.
    None if could not resolve service_name or method_name.

  Example:
  >>> get_response_type("Ergon", "TaskCreate")
  <class 'ergon.ergon_interface_pb2.TaskCreateRet'>
  """
  method_desc = get_method_descriptor(service_name, method_name)
  if method_desc:
    return _SERVICES[service_name].GetResponseClass(method_desc)
  else:
    return None

def remove_null_kwargs(func):
  """
  Decorator that removes all kwargs with values == None.
  This is useful for methods that use **kwargs to create protobuf objects.

  Example:
    @remove_null_kwargs
    def foo(**kwargs):
      return SomeProtobuf(**kwargs)  # {string a, string b}
    foo(a='a', b=None)  # b is removed, get SomeProtobuf(a='a')

  Example 2:
    remove_null_kwargs(SomeProtobuf)(**{'a': 'a', 'b': None})
  """
  def dec(*args, **kwargs):
    kwargs = dict((k, v) for (k, v) in kwargs.items() if v is not None)
    return func(*args, **kwargs)
  return dec

def set_if_present(proto_message, attribute_chain, value):
  """
  Returns True if successfully updated, else returns False.
  """
  try:
    message = proto_message
    attribute_list = attribute_chain.split('.')
    for attribute in attribute_list[:-1]:
      if message.HasField(attribute):
         message = getattr(message, attribute)
      else:
         return False
    if message.HasField(attribute_list[-1]):
      setattr(message, attribute_list[-1], value)
    else:
      return False
    return True
  except (AttributeError, ValueError):
    return False

def get_if_present(proto_message, attribute_chain, sentinel=None):
  """
  Returns Attribute if found, else returns sentinel.
  """
  try:
    message = proto_message
    attribute_list = attribute_chain.split('.')
    for attribute in attribute_list:
      if message.HasField(attribute):
        message = getattr(message, attribute)
      else:
        return sentinel
    return message
  except (AttributeError, ValueError):
    return sentinel
