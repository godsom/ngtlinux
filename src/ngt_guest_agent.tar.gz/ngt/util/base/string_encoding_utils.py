#
# Copyright (c) 2016 Nutanix Inc. All rights reserved.
#
# Author: amit.kumar@nutanix.com (Amit Kumar)
#
# Description: Provides utilities to encode and decode strings.
#
__all__ = [ "unicode_to_str", "str_to_unicode" ]

DEFAULT_ENCODING = "utf-8"

def encode_to_str(value, errors='strict'):
  """
  Method to encode 'unicode' type string to a 'str' type string.
  If value is already a 'str' type string we return it, as calling encode on str
  type will fail if string has encoded non-ascii characters.
  Args:
    value (unicode/str): Input to encode.
  Returns:
    str : The string in str type.
  """
  if type(value) == unicode:
    return value.encode(DEFAULT_ENCODING, errors)
  else:
    return value

def decode_to_unicode(value, errors='strict'):
  """
  Method to decode 'str' type string to a 'unicode' type string.
  If value is already a 'unicode' type string we return it, as calling decode on
  unicode type will fail if string has non-ascii characters.
  Args:
    value (unicode/str): Input to decode.
  Returns:
    unicode : The string in unicode.
  """
  if type(value) == str:
    return value.decode(DEFAULT_ENCODING, errors)
  else:
    return value
