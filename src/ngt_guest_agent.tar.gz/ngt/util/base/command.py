#
# Copyright (c) 2011 Nutanix Inc. All rights reserved.
#
# Author: bnc@nutanix.com
#
# DESCRIPTION: simple wrapper around subprocess.Popen to support commands with
# timeouts.
#
# Example:
#
#   rv, stdout, stderr = timed_command("ls -l /etc/", 50)
#
# The above executes "ls -l /etc" with a timeout of 50 seconds.
#
# For running commands that requires interactive keyboard input (e.g. ssh/scp
# with password), use timed_terminal_command
#
#   rv, stdout, sdderr = timed_terminal_command(
#     "ssh user@remote ls -l /etc", "my_ssh_password", 50)
#
#
__all__ = [ "timed_command", "timed_terminal_command", "run_detached_command" ]

import cStringIO
import errno
import fcntl
import os
import pty
import select
import shlex
import signal
import subprocess
import termios
import time

from log import *
from util.base.command_executor import CommandExecutor
from util.base.string_encoding_utils import encode_to_str

def read_no_eintr(read_obj, buf):
  """
  Reads from 'read_obj' and writes data into 'buf'. If there's more data to
  read from 'read_obj', returns True, else False.
  """
  has_more_data = True
  while True:
    try:
      data = read_obj.read()
      if len(data) > 0:
        buf.write(data)
      else:
        has_more_data = False
        break
    except (IOError, OSError), e:
      if e.errno == errno.EINTR:
        continue
      elif e.errno == errno.EWOULDBLOCK:
        break
      else:
        raise
  return has_more_data

def timed_poll_proc(proc, timeout_secs):
  """
  Poll subprocess's stdout and stderr until timeout or when error occurs.
  'timeout_secs' value of -1 implies no timeout.

  Returns:
    (exit code, stdout, stderr)
    If timed out, exit_code will be -1, stdout and stderr will be the partial
    outputs up to that point.
  """
  stdout = cStringIO.StringIO()
  stderr = cStringIO.StringIO()

  proc_killed = False
  poll_set = set([proc.stdout, proc.stderr])
  deadline = time.time() + timeout_secs

  for fd in poll_set:
    fl = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)

  # Read stdout and stderr from proc using non-blocking I/O until either both
  # stdout and stderr are completely read or a timeout occurs.
  while poll_set:
    try:
      if timeout_secs >= 0:
        wait_secs = max(0, deadline - time.time())
      else:
        wait_secs = None
      rd, _, err = select.select(list(poll_set), [], list(poll_set), wait_secs)
    except select.error as ex:
      if ex.args[0] == errno.EINTR:
        continue
      else:
        raise

    if err or not rd:
      try: # Best-effort attempt to kill child process.
          os.kill(proc.pid, signal.SIGKILL)
      except Exception:
        pass
      proc_killed = True
      break

    for pipe_obj in rd:
      if pipe_obj is proc.stdout:
        buf = stdout
      else:
        CHECK(pipe_obj is proc.stderr)
        buf = stderr
      if not read_no_eintr(pipe_obj, buf):
        poll_set.remove(pipe_obj)

  exit_code = proc.wait()
  return ( exit_code if not proc_killed else -1,
           stdout.getvalue(), stderr.getvalue() )

def timed_command(cmd, timeout_secs=-1, env=None, close_fds=True, shell=False,
                  cwd=None, obfuscated_cmd=None):
  """
  Execute command 'cmd' with timeout 'timeout_secs'. If env is not None, it
  specifies the environment (a dictionary) to use when executing 'cmd'.
  'timeout_secs' value of -1 implies no timeout.
  If 'obfuscated_cmd' is specified print it instead of 'cmd' in logs.

  Returns:
    (exit code, stdout, stderr)
    If timed out, the exit code will be -1, and stdout and stderr will
    be the partial output up to that point.

  Assumption: stdout and stderr for 'cmd' can fit comfortably in memory.
  """
  if not obfuscated_cmd:
    obfuscated_cmd = cmd

  try:
    # Note: we encode the string 'cmd' using the default system encoding below
    # so shlex.split works with Unicode strings. This coersion won't work for
    # Unicode strings that actually need multi-byte reprensentations of course.
    # Then again, shlex.split currently won't work with any Unicode strings, so
    # this is strictly better than just calling shlex.split(cmd). Unicode
    # support for shlex is supposedly available in Python 2.7.3.
    args = cmd if shell else shlex.split(encode_to_str(cmd))
    proc = subprocess.Popen(args, env=env, close_fds=close_fds, shell=shell,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            cwd=cwd)
    ret = timed_poll_proc(proc, timeout_secs)
    if ret[0] == -1:
      WARNING("Timeout executing %s: %d secs elapsed"
              % (obfuscated_cmd, timeout_secs))
    return ret
  except (IOError, OSError), e:
    ERROR("Failed to execute %s: %s" % (obfuscated_cmd, str(e)))
    raise e

# Wraps pid, stdout, sdterr in a subprocess.Popen like object
class PtyProc(object):
  def __init__(self, pid, stdout, stderr):
    self.pid = pid
    self.stdout = stdout
    self.stderr = stderr

  def wait(self):
    (pid, ret) = os.waitpid(self.pid, 0)
    return -os.WTERMSIG(ret) or os.WEXITSTATUS(ret)

def timed_terminal_command(cmd, keyboard_input, timeout_secs=-1,
                           env=None, cwd=None, obfuscated_cmd=None):
  """
  Execute 'cmd' interactively through a terminal with specified
  'keyboard_input' through a pseudoterminal, typically used to run commands
  that require password like ssh.
  A 'timeout_secs' value of -1 implies no timeout.
  If 'obfuscated_cmd' is specified print it instead of 'cmd' in logs.

  Returns:
    (exit code, stdout, stderr)
    If timed out, the exit code will be -1, and stdout and stderr will
    be the partial outputs up to that point.

  Assumption: stdout and stderr for 'cmd' can fit comfortably in memory.
  """
  deadline = time.time() + timeout_secs

  if not obfuscated_cmd:
    obfuscated_cmd = cmd

  try:
    (stdout_rd, stdout_wr) = os.pipe()
    (stderr_rd, stderr_wr) = os.pipe()

    # Fork subprocess in a pseudoterminal (PTY)
    (pid, term_fd) = pty.fork()
  except OSError as e:
    ERROR("Failed to execute %s: %s" % (obfuscated_cmd, str(e)))
    raise e

  if pid == 0:
    try:
      # Child process gets stdin from pty.
      # Redirect stdout, stderr goes to pipes.
      os.dup2(stdout_wr, 1)
      os.dup2(stderr_wr, 2)

      # Close pipes
      os.close(stdout_rd)
      os.close(stderr_rd)
      os.close(stdout_wr)
      os.close(stderr_wr)

      if cwd is not None:
        os.chdir(cwd)
      if env is None:
        env = os.environ
      # See comment in 'timed_command' on why we encode 'cmd' using the default
      # system encoding below.
      argv = shlex.split(encode_to_str(cmd))
      os.execvpe(argv[0], argv, env)
    except:
      import traceback
      traceback.print_exc()
      os._exit(1)

  try:
    # Parent closes write end of stdout and stderr.
    os.close(stdout_wr)
    os.close(stderr_wr)

    # Wait for some kind of a prompt on terminal before sending input,
    # note we don't actually care what it is, which is fine
    # for running one ssh command at a time.
    while True:
      try:
        if timeout_secs >= 0:
          wait_secs = max(0, deadline - time.time())
        else:
          wait_secs = None
        rd, _, _ = select.select([term_fd], [], [term_fd], wait_secs)
        break
      except select.error as ex:
        if ex.args[0] == errno.EINTR:
          continue
        else:
          raise

    # Wrap fds in file objs, they will be closed when the file objects
    # are closed. Note that term is unbuffered.
    term = os.fdopen(term_fd, "r+", 0)
    stdout = os.fdopen(stdout_rd, "r")
    stderr = os.fdopen(stderr_rd, "r")

    # Parent will send input to child via terminal.
    term.write(keyboard_input)
    term.write(os.linesep)
    term.write(chr(termios.CEOF))

    if timeout_secs >= 0:
      wait_secs = max(0, deadline - time.time())
    else:
      wait_secs = -1
    ret = timed_poll_proc(PtyProc(pid, stdout, stderr), wait_secs)
    if ret[0] == -1:
      WARNING("Timeout executing %s: %d secs elapsed" %
              (obfuscated_cmd, timeout_secs))
    return ret

  except (IOError, OSError), e:
    ERROR("Failed to execute %s: %s" % (obfuscated_cmd, str(e)))
    raise e

def run_detached_command(cmd, env=None):
  """
  Runs command in a detached manner. Killing the parent will not kill the
  child. This is to be used for processes which will definitely exit. No
  timeout is specified for this command.

  Returns:
    (exit code, stdout, stderr)
    If timed out, the exit code will be -1, and stdout and stderr will
    be the partial outputs up to that point.

  Assumption: stdout and stderr for 'cmd' can fit comfortably in memory.
  """
  args = shlex.split(encode_to_str(cmd))
  ce = CommandExecutor()
  cmd_id = ce.execute(args[0], args, env, opts="TEMPFILES", detached=True)

  # Always wait in intervals of 2 seconds.
  while ce.num_unfinished():
    ce.wait(2.0)

  finished = ce.finished()
  CHECK(len(finished) == 1)

  # Get the return values.
  status, stdout, stderr = ce.result(cmd_id)
  ret_out = stdout.read()
  ret_err = stderr.read()
  exited = os.WIFEXITED(status)
  rv = os.WEXITSTATUS(status)

  if not exited:
    ERROR("Command %s did not finish, ret %s, stdout %s, stderr %s" %
          (cmd, rv, ret_out, ret_err))
    rv = -1

  return rv, ret_out, ret_err
