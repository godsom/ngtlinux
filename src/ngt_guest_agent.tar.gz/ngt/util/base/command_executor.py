#
# Copyright (c) 2012 Nutanix Inc. All rights reserved.
#
# Author: bvk@nutanix.com
#
# This file defines CommandExecutor class. Its objects can execute multiple
# commands in parallel using a configurable number of child processes.
#
# Usage:
#
#   pp = CommandExecutor(num_workers=5)
#   ...
#   pp.execute(cmd1, args1)
#   pp.execute(cmd2, args2, env)
#   pp.execute(cmd3, args3)
#   pp.execute(cmd4, args4, env)
#   pp.execute(cmd5, args5, env, opts=TEMPFILES)
#   ...
#   finished = pp.wait(10)
#   for ii in finished:
#     rv, stdout, stderr = pp.result(ii)
#
# Implementation Notes
#
# 1. Commands registered with command executor are executed in FIFO order, but
#    their finish order depends on the time taken by the command. So commands
#    that are farther behind may finish before their predecessors.
#
# 2. CommandExecutor class doesn't make use of python's threading library (or
#    multiprocessings library). So new process scheduling doesn't happen
#    automatically. Main thread has to perform CommandExecutor.wait() or
#    CommandExecutor.schedule() periodically. These methods will create new
#    processes when they find that 'num_workers' child processes aren't
#    executing already.
#
# 3. CommandExecutor.wait() method epolls for stdout/stderr data from the child
#    processes. If NO child processes use PIPES for stdout/stderr data, then
#    CommandExecutor.wait() sleeps for the specified amount of time, optionally
#    invoking the CommandExecutor.schedule() method.

from ctypes import CDLL
from ctypes.util import find_library
import base64
import cStringIO
import errno
import fcntl
import os
import select
import signal
import socket
import tempfile
import threading
import time
import traceback

from util.base.log import *

libc = CDLL(find_library("c"))
SET_PDEATHSIG = 1

PIPES = "PIPES"
TEMPFILES = "TEMPFILES"

CHUNK_SIZE = 8192

def _set_non_blocking(fd):
  """
  Set a file descriptor in non-blocking mode.

  Returns the input fd.
  """
  try:
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
    return fd
  except IOError as ex:
    FATAL(traceback.format_exc())

def _set_blocking(fd):
  """
  Set a file descriptor in blocking mode.

  Returns the input fd.
  """
  try:
    flags = fcntl.fcntl(fd, fcntl.F_GETFL)
    fcntl.fcntl(fd, fcntl.F_SETFL, flags & ~os.O_NONBLOCK)
    return fd
  except IOError as ex:
    FATAL(traceback.format_exc())

def _select_no_eintr(read_fds, write_fds, except_fds, timeout=None):
  """
  Select wrapper that ignores EINTR and fatals on all other errors.
  """
  while True:
    try:
      return select.select(read_fds, write_fds, except_fds, timeout)
    except select.error as ex:
      if ex[0] == errno.EINTR:
        continue
      FATAL(traceback.format_exc())

class CommandExecutor(object):

  # Status value for a finished command. A command's exit event, stdout-close
  # event and stderr-close event each contribute one count to this integer.
  COMPLETED_COMMAND_STATUS = 3

  def __init__(self, num_workers=1):
    """
    Creates a CommandExecutor object that can execute 'num_workers' commands in
    parallel.
    """
    # Maximum number of worker processes.
    self.__num_workers = num_workers

    # Lock used to avoid race from signal handlers.
    self.__lock = threading.Lock()

    # Reset the command pool state.
    with self.__lock:
      self.__reset()

  def __reset(self):
    """
    Reinitialize the command pool with a clean state.  All the old state is
    freed.
    """
    CHECK(not self.__lock.acquire(False))
    # List of commands in (cmd, args, env, opts) tuple form in the FIFO
    # order. This list contains ALL commands that were/are/will-be executed
    # using this executor. This list forms the basis for unique command
    # indicies.
    self.__commands = []

    # Mapping from currently active pid to its command index. This mapping
    # contains pids of the active child processes. An entry is added into this
    # mapping when a new child process is created. And when a child process
    # exits, relevant entry in this mapping is removed.
    self.__pid_index_map = {}

    # List of tuples in (rv, file/cStringIO/fd for stdout, file/cStringIO/fd
    # for stderr) form for each command in the commands list. This list
    # contains information for commands that were completed or are currently
    # executing. The rv member is set to None for commands that are currenly
    # executing and it will be updated when the corresponding command finishes
    # execution.
    self.__exec_info = []

    # Mapping from command index to the current status of the command. Command
    # status is stored as an integer. If a command is finished, then its status
    # is incremented to COMPLETED_COMMAND_STATUS.
    self.__command_status_map = {}

    # Mapping from fd to the index of the command that owns the file
    # descriptor. This mapping contains stdout and stderr read ends for the
    # commands that are currently executing. Two new entries -- one for stdout
    # and another for stderr -- are added into this mapping when a new child
    # process that wants its stdout and stderr to be processed using PIPES is
    # created. And the two corresponding entries are removed when
    # CommandExecutor.result() method returns the stdout and stderr contents.
    self.__fd_index_map = {}

    # Mapping from (index, file descriptor) pair to a cStringIO object with
    # data read from the file descriptor in the epolls. This mapping contains
    # information for commands that were completed or are currently
    # executing. It is updated whenever some data is read from an fd after the
    # epoll. Data is deleted when CommandExecutor.result() method returns the
    # stdout and stderr contents.
    self.__fd_data = {}

  def status(self):
    """
    Returns a dict with strings 'total', 'finished' and 'running' mapping to
    the number of commands registered, number of commands finished execution
    and the number of commands currently executing respectively.
    """
    with self.__lock:
      num_commands = len(self.__commands)
      num_running = len(self.__pid_index_map)
      num_finished = len(self.__exec_info) - num_running
      return {"total": num_commands, "finished": num_finished,
              "running": num_running}

  def shutdown(self):
    """
    Force kill the running processes and cleanup all resources.
    """
    with self.__lock:
      try:
        # Kill all child processes.
        for pid in self.__pid_index_map.keys():
          os.kill(pid, signal.SIGKILL)

        # Cleanup all zombies.
        self.__check_for_completions()

        # Free up cStringIO resources for PIPE ends.
        cstringio_type = type(cStringIO.StringIO())
        for sio in self.__fd_data.values():
          CHECK_EQ(type(sio), cstringio_type)
          sio.close()

        # Close all files and cstringio objects.
        for index in xrange(len(self.__exec_info)):
          rv, stdout, stderr = self.__exec_info[index]

          # Command had failed to execute.
          if stdout == None and stderr == None: continue

          # Free up resources.
          for output in [stdout, stderr]:
            if type(output) == file or type(output) == cstringio_type:
              output.close()
            else:
              # Close read ends for commands executing in PIPES mode.
              CHECK_EQ(type(output), int)
              os.close(output)

      except OSError as ex:
        FATAL(traceback.format_exc())
      # Reset all data structures
      self.__reset()
      CHECK(not self.__finished())
      CHECK_EQ(self.__num_unfinished(), 0)

  def get_command(self, index):
    """
    Returns the command with id 'index' in (cmd, args, env) form.
    """
    return self.__commands[index][0:3]

  def result(self, index):
    """
    Returns the output of command with id 'index' in (rv, stdout, stderr)
    form.

    If the command was executed in PIPES mode, stdout and stderr fields are
    cStringIO descriptors and if command was executed in TEMPFILES mode, stdout
    and stderr files are file descriptors to the temporary files that contain
    the real data.

    Returns (None, None, None) if command is not yet completed and returns (-1,
    None, None) if command had failed to execute.
    """
    # The num_finished method can return that all commands have finished
    # execution, but we may not have read their stdout and stderr data yet. So
    # perform a non-blocking poll and read any pending data before returning
    # the result.
    self.__poll(0)

    with self.__lock:
      # Command is not yet started.
      if index >= len(self.__exec_info):
        return None, None, None

      # Command is still executing.
      CHECK_LE(self.__command_status_map.get(index, 0),
               self.COMPLETED_COMMAND_STATUS)
      if (self.__command_status_map.get(index, 0) <
          self.COMPLETED_COMMAND_STATUS):
        return None, None, None

      none_type = type(None)
      cstringio_type = type(cStringIO.StringIO())
      rv, stdout, stderr = self.__exec_info[index]
      CHECK(rv is not None)
      CHECK(type(stdout) in [none_type, cstringio_type, str, file])
      CHECK(type(stderr) in [none_type, cstringio_type, str, file])
      # If output is in cStringIO objects form convert it to string.
      out = stdout
      if type(stdout) is cstringio_type:
        stdout.seek(0, os.SEEK_SET)
        out = stdout.getvalue()
      # If output is of type file seek to the beginning of file.
      if type(stdout) == file:
        out.seek(0, os.SEEK_SET)

      err = stderr
      if type(stderr) is cstringio_type:
        stderr.seek(0, os.SEEK_SET)
        err = stderr.getvalue()
      # If stderr is of type file seek to the beginning of file.
      if type(stderr) == file:
        err.seek(0, os.SEEK_SET)
      return rv, out, err

  def num_unfinished(self):
    """
    Returns number of commands that are executing or pending for execution.
    """
    with self.__lock:
      return self.__num_unfinished()

  def __num_unfinished(self):
    CHECK(not self.__lock.acquire(False))
    num_commands = len(self.__commands)
    num_running = len(self.__pid_index_map)
    num_finished = len(self.__exec_info) - num_running
    return num_commands - num_finished

  def finished(self):
    """
    Returns array of command ids that had finished execution and has the
    results ready.
    """
    with self.__lock:
      return self.__finished()

  def __finished(self):
    CHECK(not self.__lock.acquire(False))
    ids = []
    for ii in xrange(len(self.__exec_info)):
      # Command execution is not yet completed.
      if self.__exec_info[ii][0] == None:
        continue

      ids.append(ii)
    return ids

  def wait(self, timeout_secs, wait_unit_secs=0.1):
    """
    Blocks for at most 'timeout_secs' time for the commands to finish.

    timeout_secs: A float specifying the amount of time to poll/sleep for the
                  commands to finish.

    wait_unit_secs: A float specifying the unit of poll/sleep time after which
                    a schedule is attempted.

    Returns array of command ids that have finished execution.
    """
    self.schedule()

    if timeout_secs <= 0:
      return self.finished()

    # Wait until the timeout expires or all commands complete.
    end = time.time() + timeout_secs
    num_unfinished = self.num_unfinished()
    while num_unfinished and time.time() < end:
      if self.__fd_index_map:
        self.__poll(max(0, end - time.time()))
      else:
        time.sleep(wait_unit_secs)

      self.schedule()
      num_unfinished = self.num_unfinished()
    return self.finished()

  def execute(self, cmd, args, env=None, opts=PIPES, detached=False):
    """
    Enqueues a new command for execution. This method implicitly invokes the
    CommandExecutor.schedule() method.

    cmd: A string that is the command name to execute. This is normally the
         same as args[0].

    args: A list of strings that are to be passed as command line arguments to
          the command.

    env: A mapping which is used to define the environment variables for the
         new process. When env is None current processes' environment is
         inherited.

    opts: Must be one of PIPES or TEMPFILES. When it is PIPES, command's stdout
          and stderr are collected using pipes. When it is TEMPFILES, command's
          stdout and stderr are redirected to temporary files instead.

    Returns unique id for the command. This id can be used to retrieve the
    command status.
    """
    CHECK(opts in [PIPES, TEMPFILES])
    index = -1
    free_workers = False
    with self.__lock:
      CHECK(type(args) == list or type(args) == tuple)
      self.__commands.append((cmd, args, env, opts, detached))
      index = len(self.__commands) - 1
      num_running = len(self.__pid_index_map)
      free_workers = num_running < self.__num_workers

    if free_workers:
      self.schedule()
      self.__poll(0)
    return index

  def schedule(self, signum=None, frame=None):
    """
    Checks for completed commands and schedules new commands.

    This methods returns immediately if lock cannot be acquired.

    The 'signum' and 'frame' parameters are always ignored. They exist only to
    satisfy the signal handler requirements.
    """
    if not self.__lock.acquire(False):
      return

    try:
      self.__check_for_completions()
      while True:
        num_commands = len(self.__commands)
        num_running = len(self.__pid_index_map)
        num_finished = len(self.__exec_info) - num_running
        num_pending = num_commands - num_finished - num_running

        CHECK_LE(num_finished, num_commands)
        CHECK_LE(num_running, self.__num_workers)
        CHECK_LE(num_running + num_finished, num_commands)

        # Check if new child processes can be created.
        if num_pending == 0 or num_running >= self.__num_workers:
          break

        # There is room for new child processes, so pick next command from the
        # commands list and create a new process.
        index = len(self.__exec_info)
        cmd, args, env, opts, detached = self.__commands[index]
        if opts == TEMPFILES:
          self.__run_cmd_with_temporary_files(index, cmd, args, env, detached)
        else:
          CHECK_EQ(opts, PIPES)
          self.__run_cmd_with_pipes(index, cmd, args, env)
    finally:
      self.__lock.release()

  def __run_cmd_with_pipes(self, index, cmd, args, env):
    """
    Fork a child process and execute a command. If fork operation fails or
    command is invalid, its result is set to (-1, None, None).

    The stdout and stderr of the child process created are accessible through
    pipes.
    """
    CHECK(not self.__lock.acquire(False))
    stdout_r = stdout_w = stderr_r = stderr_w = None
    try:
      stdout_r, stdout_w = os.pipe()
      stderr_r, stderr_w = os.pipe()
      pid = os.fork()
      if pid == 0:
        try:
          os.dup2(os.open(os.devnull, os.O_RDONLY), 0)
          os.dup2(stdout_w, 1)
          os.dup2(stderr_w, 2)
          os.closerange(3, max(map(int, os.listdir("/proc/self/fd"))) + 1)
          if env:
            os.execvpe(cmd, args, env)
          else:
            os.execvp(cmd, args)
        except Exception as ex:
          # We come here implies execvp failed. So mark the command as failed.
          ERROR("failed to execute child command: %s" % cmd)
          ERROR(traceback.format_exc())
        finally:
          os._exit(1)
      else:
        CHECK_GT(pid, 0)
        os.close(stdout_w)
        os.close(stderr_w)
        # Save the pid, stdout and stderr details.
        self.__pid_index_map[pid] = index
        _set_non_blocking(stdout_r)
        _set_non_blocking(stderr_r)
        self.__exec_info.append((None, stdout_r, stderr_r))
        self.__fd_index_map[stdout_r] = index
        self.__fd_index_map[stderr_r] = index
        # Initialize the corresponding fd data map with empty content.
        self.__fd_data[(index, stdout_r)] = cStringIO.StringIO()
        self.__fd_data[(index, stderr_r)] = cStringIO.StringIO()
    except OSError as ex:
      self.__command_status_map[index] = self.COMPLETED_COMMAND_STATUS
      self.__exec_info.append((-1, None, None))
      ERROR(traceback.format_exc())
      for fd in [stdout_r, stdout_w, stderr_r, stderr_w]:
        if fd: os.close(fd)
    finally:
      CHECK_EQ(len(self.__exec_info), index + 1)

  def __run_cmd_with_temporary_files(self, index, cmd, args, env, detached):
    """
    Fork a child process and execute a command. If fork operation fails or
    command is invalid, its result is set to (-1, None, None).

    The stdout and stderr of the child process are accessible through temporary
    files.
    """
    CHECK(not self.__lock.acquire(False))
    stdout_file = stderr_file = None
    try:
      stdout_file = tempfile.TemporaryFile(prefix="stdout")
      stderr_file = tempfile.TemporaryFile(prefix="stderr")
      pid = os.fork()
      if detached:
        os.setpgid(pid, pid)
      if pid == 0:
        try:
          # Redirect the stdout and stderr into temporary files.
          os.dup2(os.open(os.devnull, os.O_RDONLY), 0)
          os.dup2(stdout_file.fileno(), 1)
          os.dup2(stderr_file.fileno(), 2)
          os.closerange(3, max(map(int, os.listdir("/proc/self/fd"))) + 1)
          if env:
            os.execvpe(cmd, args, env)
          else:
            os.execvp(cmd, args)
        except Exception as ex:
          # We come here implies execvp failed. So mark the command as failed.
          ERROR("failed to execute child command: %s" % cmd)
          ERROR(traceback.format_exc())
        finally:
          os._exit(1)
      else:
        CHECK_GT(pid, 0)
        # Save the pid, stdout, stderr details.
        self.__pid_index_map[pid] = index
        self.__exec_info.append((None, stdout_file, stderr_file))
    except OSError as ex:
      self.__command_status_map[index] = self.COMPLETED_COMMAND_STATUS
      self.__exec_info.append((-1, None, None))
      ERROR(traceback.format_exc())
      for filep in [stdout_file, stderr_file]:
        if filep: filep.close()
    finally:
      CHECK_EQ(len(self.__exec_info), index + 1)

  def __check_for_completions(self):
    """
    Collects the exit status for child processes.
    """
    try:
      CHECK(not self.__lock.acquire(False))
      pids = self.__pid_index_map.keys()
      for pid in pids:
        pp, status = os.waitpid(pid, os.WNOHANG)
        if pp == 0: continue

        # Process has completed execution. Remove it from the pid_index_map.
        CHECK_EQ(pp, pid)
        index = self.__pid_index_map[pid]
        del self.__pid_index_map[pid]

        # Update the exit status in the exec_info.
        none, stdout, stderr = self.__exec_info[index];
        self.__exec_info[index] = (status, stdout, stderr)

        # If command output is captured into temporary files, we don't poll for
        # data, so command completion is also treated as the stdin and stdout
        # close.
        if type(stdout) == file:
          CHECK_EQ(self.__command_status_map.get(index), None)
          self.__command_status_map[index] = self.COMPLETED_COMMAND_STATUS
        else:
          CHECK_LE(self.__command_status_map.get(index, 0),
                   self.COMPLETED_COMMAND_STATUS)
          self.__command_status_map[index] = 1 + self.__command_status_map.get(
            index, 0)

    except OSError as ex:
      FATAL(traceback.format_exc())

  def __poll(self, timeout_secs):
    """
    Poll read ends of child processes' stdout and stderr for upto
    'timeout_secs' time and read any available data.
    """
    fds_to_poll = []
    fds_with_data = []
    with self.__lock:
      fds_to_poll = self.__fd_index_map.keys()
      if not fds_to_poll: return

    # Create a polling object with stdout/stderr pipe fds.
    fds_with_data = []
    rd, _, err = _select_no_eintr(fds_to_poll, [], fds_to_poll, timeout_secs)
    fds_with_data = list(set(rd + err))
    if not fds_with_data:
      return

    # Some fds have data. Read the data without blocking.
    with self.__lock:
      for fd in fds_with_data:
        index = self.__fd_index_map[fd]
        cstringio = self.__fd_data[(index, fd)]
        try:
          while True:
            data = os.read(fd, CHUNK_SIZE)
            if not data: break
            cstringio.write(data)
        except OSError as ex:
          if ex.errno in (errno.EWOULDBLOCK, errno.EAGAIN):
            continue
          FATAL(traceback.format_exc())

        # Pipe fd is closed, so update the command status and move the
        # cStringIO object into exec_info and delete the fd metadata.

        CHECK_LE(self.__command_status_map.get(index, 0),
                 self.COMPLETED_COMMAND_STATUS)
        self.__command_status_map[index] = 1 + self.__command_status_map.get(
          index, 0)

        rv, stdout, stderr = self.__exec_info[index]
        if stdout == fd:
          self.__exec_info[index] = (rv, cstringio, stderr)
        if stderr == fd:
          self.__exec_info[index] = (rv, stdout, cstringio)

        del self.__fd_index_map[fd]
        del self.__fd_data[(index, fd)]
        os.close(fd)

  def __enter__(self):
    """
    Returns self when entering the "with" clause.
    """
    return self

  def __exit__(self, ty, ex, tb):
    """
    Shutdown the CommandExecutor when "with" clause scope is finished.

    ty: The exception type.

    ex: The exception object.

    tb: The exception traceback.

    Returns False.
    """
    self.shutdown()
    # Don't suppress any exceptions.
    return False

class _Popen2File(object):
  def __init__(self, pid, sock, stderr_path=None):
    self.__pid = pid
    self.__sock = sock
    self._stderr_path = stderr_path

  def __del__(self):
    self.close()

  def close_stdin(self):
    """
    Sends EOF to the child process's stdin.
    """
    self.__sock.shutdown(socket.SHUT_WR)

  def wait(self, timeout=1e9):
    """
    Wait for subprocess to complete, return status, or None if subprocess
    has not terminated when timeout expired.
    """
    deadline = time.time() + timeout
    while True:
      # Coroutine friendly way of waitpid()
      pid, status = os.waitpid(self.__pid, os.WNOHANG)
      if pid:
        self.__pid = None
        return status
      if time.time() > deadline:
        break
      time.sleep(0.1)

  def kill(self, sig=signal.SIGKILL):
    """
    Kill the subprocess with signal.
    """
    os.kill(self.__pid, sig)

  def close(self):
    if not self.__pid:
      return

    self.__sock.close()
    if self._stderr_path is not None:
      os.unlink(self._stderr_path)
      self._stderr_path = None

    # Wait for up to 1 second for process to exit on its own, then send KILL.
    if self.wait(1.0) is not None:
      return

    self.kill()
    CHECK(self.wait(1.0) is not None)

  def read(self, size=1024*1024):
    """
    Reads from stdout of subprocess.
    """
    return self.__sock.recv(size)

  def write(self, data):
    """
    Writes to stdin of subprocess.
    """
    return self.__sock.sendall(data)

  def stderr(self, size=1024 * 1024, offset=0):
    """
    Reads from stderr of the subprocess.
    """
    if self._stderr_path is not None:
      with open(self._stderr_path) as stderr:
        stderr.seek(offset)
        return stderr.read(size)
    else:
      return ""

  # Socket-like aliases.
  recv = read
  sendall = write
  send = write

  @property
  def socket(self):
    """
    Returns the socket to the subprocess for direct communication.
    """
    return self.__sock

  @property
  def pid(self):
    """
    Returns the pid of the subprocess.
    """
    return self.__pid

class RedirectExecutor(object):
  def __init__(self, stdin=None, stdout=None, stderr=None):
    """
    Initialize a RedirectExecutor. The RedirectExecutor can be used as a
    wrapper around a child process and can be used to pipe in file descriptors
    to be used in place of STDIN, STDOUT, and STDERR.

    Args:
      stdin (int): File descriptor to use for stdin.
      stdout (int): File descriptor to use for stdout.
      stderr (int): File descriptor to use for stderr.
    """
    self._stdin = stdin
    self._stdout = stdout
    self._stderr = stderr

  def execute(self, cmd, args, env=None):
    """
    Create a new child process and returns the pid of that child process.

    Args:
      cmd (string): Path to the command to execute.
      args ([ string ]): String arguments to pass to the command.
      env ({ string: string }): Command environment.
    Returns:
      int
    """
    pid = os.fork()
    if pid == 0:
      libc.prctl(SET_PDEATHSIG, signal.SIGTERM)
      try:
        if self._stdin is not None:
          os.dup2(self._stdin, 0)
        if self._stdout is not None:
          os.dup2(self._stdout, 1)
        if self._stderr is not None:
          os.dup2(self._stderr, 2)
        os.closerange(3, max(map(int, os.listdir("/proc/self/fd"))) + 1)
        if env:
          os.execvpe(cmd, args, env)
        else:
          os.execvp(cmd, args)
      finally:
        os._exit(1)
    return pid

class StreamingExecutor(object):
  @staticmethod
  def execute(cmd, args, env=None, pipe_stderr=False):
    """
    A command executor that returns a file like object for streaming the
    subprocess's stdin and stdout.

    Args:
      cmd (string): Path to the command executable.
      args ([ string ]): List of command arguments.
      env ({ string: string }): Command environment variables.
      pipe_stderr (bool): If true we will pipe stderr to a temporary file.
    Return:
      _Popen2File
    """
    sockpair = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM, 0)
    stderr_path = None
    if pipe_stderr:
      stderr_fd, stderr_path = tempfile.mkstemp()
    else:
      stderr_fd = os.open("/dev/null", os.O_RDONLY | os.O_WRONLY)

    pid = RedirectExecutor(stdin=sockpair[1].fileno(),
                           stdout=sockpair[1].fileno(),
                           stderr=stderr_fd).execute(cmd, args, env=env)

    os.close(stderr_fd)
    sockpair[1].close()
    return _Popen2File(pid, sockpair[0], stderr_path)
