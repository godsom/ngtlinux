#
# Copyright (c) 2015 Nutanix Inc.  All rights reserved.
#
# Author: ankush.jindal@nutanix.com (Ankush Jindal)
#
# This file provides a python interface for ngt guest server. It uses
# the SyncRpcClientMixin helper class defined in
# util/py/util/net/sync_rpc_client.py.
#
# This client is not intended to be "thread-safe".
#

import gflags
import platform
import re
import time
import util.base.log as log

from util.base.log import *
from util.net.http_protobuf_rpc import HttpProtobufRpcClient
from util.net.https_protobuf_rpc import HttpsProtobufRpcClient
from util.net.sync_rpc_client import *

from ngt.base.ngt_error_pb2 import NgtErrorProto
from ngt.interface.ngt_guest_interface_pb2 import *

FLAGS = gflags.FLAGS
gflags.DEFINE_integer("ngt_guest_port",
                      2074,
                      "Port where ngt guest server listens.");

gflags.DEFINE_string("ngt_host",
                     "127.0.0.1",
                     "Host where ngt guest server resides")

gflags.DEFINE_integer("maximum_attempts_on_ngt_retry_request",
                      3,
                      "Maximum number of attempts when ngt requests a retry"
                      " error")

gflags.DEFINE_integer("ngt_retry_delay_ms", 5000,
                      "The maximum delay between retries in ms.")

gflags.DEFINE_string("ngt_client_certificate",
                     "/home/nutanix/client-cert.pem",
                     "Client certificate to connect to ngt service")

gflags.DEFINE_string("ngt_client_key",
                     "/home/nutanix/client-key.pem",
                     "Client's key to connect to ngt service")

gflags.DEFINE_string("ngt_ca_certificate",
                     "/home/nutanix/ca-cert.pem",
                     "CA certificate to connect to ngt service")

gflags.DEFINE_string("ngt_use_secure",
                     True,
                     "Flag to use secure channel to connect to ngt")

def Initialize():
  """
  Initialize gflags according to the operating system.
  """
  if platform.system() == 'Linux':
    InitializeLinux()
  elif platform.system() == 'Windows':
    InitializeWindows()
  else:
    FATAL("Operating system not supported")

def InitializeLinux():
  """
  Initialize gflags for Linux.
  """
  FLAGS.ngt_client_certificate = "/usr/local/nutanix/config/client-cert.pem"

  FLAGS.ngt_client_key = "/usr/local/nutanix/config/client-key.pem"

  FLAGS.ngt_ca_certificate = "/usr/local/nutanix/config/ca-cert.pem"

def InitializeWindows():
  """
  Initialize gflags for Windows.
  """
  FLAGS.ngt_client_certificate = \
    (FLAGS.ngt_installation_path + "config\\client-cert.pem")

  FLAGS.ngt_client_key = \
    (FLAGS.ngt_installation_path + "config\\client-key.pem")

  FLAGS.ngt_ca_certificate = \
    (FLAGS.ngt_installation_path + "config\\ca-cert.pem")

class NgtInterfaceError(Exception):
  """
  Encapsulates any errors thrown by the RPC server into a Python Exception. The
  consumer of the NgtGuestInterface class can 'catch' these errors to find out
  if the RPC server encountered any errors while processing the request.
  """
  def __init__(self, message, error_code=None):
    Exception.__init__(self, message)
    if error_code is not None:
      self.error_code = error_code

NgtGuestMetaSyncRpcClient = sync_rpc_client_metaclass(NgtGuestRpcSvc_Stub)

class NgtGuestInterfaceClient(SyncRpcClientMixin):
  """
  Python client to the Ngt guest RPC service. To use this class first
  instantiate the class with two arguments: 1) IP of the RPC server, 2) Port
  where the RPC server is running. Then directly call the RPC methods
  on this RPC server. These methods can be found in ngt_guest_interface.proto.
  Example Usage:

  ngt_guest_rpc_client = NgtGuestInterfaceClient(ngt_host, ngt_guest_port)
  try:
    query_vm_snapshot_arg = QueryVmSnapshotArg()
    query_vm_snapshot_arg.ngt_uuid = ngt_uuid
    query_vm_snapshot_ret =
      ngt_guest_rpc_client.QueryVmSnapshot(query_vm_snapshot_arg)
  except NgtInterfaceError as e:
    .....
  except RpcClientError as e:
    .....
  """
  __metaclass__ = NgtGuestMetaSyncRpcClient

  def __init__(self, ngt_host, ngt_guest_port, connection_timeout=None,
               use_secure_communication=None):
    """
    Instantiates state creating a SyncRpcClientMixin object.

    Args:
      ngt_host (string): IP Address of the Ngt guest RPC Server.
      ngt_guest_port (integer): Port number of the Ngt guest RPC Server.
    """
    Initialize()
    SyncRpcClientMixin.__init__(self, NgtErrorProto)
    self.__ngt_adapter_ip = ngt_host
    self.__ngt_adapter_port = ngt_guest_port
    self.__ngt_connection_timeout = connection_timeout
    CHECK(self.__ngt_connection_timeout)
    if use_secure_communication is not None:
      FLAGS.ngt_use_secure = use_secure_communication

  def _create_stub(self):
    """
    Creates a new stub with backing transport.
    """
    if FLAGS.ngt_use_secure:
      rpc_client = HttpsProtobufRpcClient(
        self.__ngt_adapter_ip,
        self.__ngt_adapter_port,
        key_file=FLAGS.ngt_client_key,
        cert_file=FLAGS.ngt_client_certificate,
        ca_file=FLAGS.ngt_ca_certificate,
        timeout_secs=self.__ngt_connection_timeout)
    else:
      rpc_client = HttpProtobufRpcClient(
        self.__ngt_adapter_ip,
        self.__ngt_adapter_port,
        timeout_secs=self.__ngt_connection_timeout)

    return NgtGuestRpcSvc_Stub(rpc_client)

  def _filter_rpc_result(self, rpc, err, ret):
    """
    Filters the return value for RPC method invocations.

    Errors are converted to exceptions, the RPC context is dropped entirely,
    and only the result is returned.

    Args:
      rpc (ProtobufRpc): The RPC context.
      err (NgtErrorProto.Type): The application error sent by the RPC
                                     server.
      ret (Message): The protobuf result.
    Returns:
      ret
    Raises:
      NgtInterfaceError
    """
    if err != NgtErrorProto.kNoError:
      raise NgtInterfaceError(self.strerror(), error_code=err)
    return ret

class NgtGuestMetaClient(NgtGuestMetaSyncRpcClient):
  """
  Metaclass that makes requests to ngt master. Retries for configured
  ngt_application_retry_count times when the rpc returns kRetry.
  """
  def __new__(mcs, class_name, bases, dikt):
    for method in NgtGuestRpcSvc_Stub.DESCRIPTOR.methods:
      name = method.name
      if name != "GetMasterLocation":
        (wrapped_name, wrapped_func) = mcs.__reflect_master_method(name)
        dikt[wrapped_name] = wrapped_func

    return NgtGuestMetaSyncRpcClient.__new__(mcs, class_name, bases, dikt)

  @staticmethod
  def __reflect_master_method(name):
    def method_wrapper(self, arg):
      # Number of retries performed when rpc returns kRetry.
      ngt_application_retry_count = 0

      while True:
        try:
          if self._master_client is None:
            ret = getattr(self, name)(arg)
          else:
            ret = getattr(self._master_client, name)(arg)
          return ret
        except NgtInterfaceError as e:
          if ((e.error_code == NgtErrorProto.kRetry) and
              (ngt_application_retry_count <
                FLAGS.maximum_attempts_on_ngt_retry_request)):
            ngt_application_retry_count += 1
            delay_ms = (
              min(FLAGS.ngt_retry_delay_ms,
                  100 << ngt_application_retry_count))
            log.INFO("Retrying %s due to kRetry in %u ms. Retry count %d" %
                     (name, delay_ms, ngt_application_retry_count))
            time.sleep(delay_ms/1e3)
            continue
          raise
        except RpcClientTransportError:
          raise NgtInterfaceError("Transport error",
                  NgtInterfaceError.kTransportError)
        except RpcClientError:
          # For other errors, raise a exception with kUnknown type.
          raise NgtInterfaceError("Unknown error",
                  NgtInterfaceError.kUnkown)

    split_func_name = re.findall("[A-Z][a-z]*", name)
    new_name = ""
    for comp in split_func_name:
      new_name += comp.lower()
      new_name += "_"
    new_name = new_name[:-1]

    method_wrapper.__name__ = new_name
    method_wrapper.__doc__ = """
    Invokes %s, retries %d number of times when ngt service requests for
    a retry"
    """ % (name, FLAGS.maximum_attempts_on_ngt_retry_request)

    return (new_name, method_wrapper)

class NgtGuestInterfaceTool(NgtGuestInterfaceClient):
  __metaclass__ = NgtGuestMetaClient

  def __init__(self, ngt_host=None, ngt_guest_port=None):
    self._master_client = None
    if ngt_host is None:
      ngt_host = FLAGS.ngt_host
    if ngt_guest_port is None:
      ngt_guest_port = FLAGS.ngt_guest_port
    NgtGuestInterfaceClient.__init__(self, ngt_host, ngt_guest_port)

  def _create_master_client(self, ngt_host, ngt_guest_port):
    self._master_client = NgtGuestInterfaceClient(ngt_host, ngt_guest_port)
